# Passive reference
