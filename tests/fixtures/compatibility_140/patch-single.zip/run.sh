#!/usr/bin/env bash
# PATCHHARBOR
set -eu
git add -- tracked.txt payload.sh
git commit --quiet -m "fixture single"
