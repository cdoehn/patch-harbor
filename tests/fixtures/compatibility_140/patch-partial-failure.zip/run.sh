#!/usr/bin/env bash
# PATCHHARBOR
set -eu
git add -- tracked.txt
git commit --quiet -m "fixture partial progress"
printf "uncommitted after failure\n" > tracked.txt
printf "public untracked\n" > failed-untracked.txt
exit 7
