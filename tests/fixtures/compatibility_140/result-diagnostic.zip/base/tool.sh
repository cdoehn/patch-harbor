#!/bin/sh
printf fixture
