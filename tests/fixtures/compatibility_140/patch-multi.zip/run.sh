#!/usr/bin/env bash
# PATCHHARBOR
set -eu
git add -- tracked.txt
git commit --quiet -m "fixture multi first"
printf "two-b\n" > tracked.txt
git add -- tracked.txt
git commit --quiet -m "fixture multi second"
