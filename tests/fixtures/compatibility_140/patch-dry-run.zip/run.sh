#!/usr/bin/env bash
# PATCHHARBOR
set -eu
printf forbidden > dry-run-executed.txt
