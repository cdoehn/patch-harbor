"""Orchestrate one manual PatchHarbor Result Bundle request."""

from __future__ import annotations

from contextlib import ExitStack
from collections.abc import Callable
from dataclasses import dataclass, replace
import json
import os
from pathlib import Path
from uuid import UUID

from patchharbor.archive_git import completed_commit_for_context
from patchharbor.bundle_handoff import BundleHandoff
from patchharbor.configuration_context import configuration_paths_for_id
from patchharbor.errors import (
    FailureReason,
    PatchHarborError,
    repository_resolution_error,
    result_bundle_error,
)
from patchharbor.json_document import serialize_json_document
from patchharbor.locks import registry_lock, repository_lock
from patchharbor.models import (
    RegistrySnapshot,
    RepositoryContext,
    RepositoryId,
    RepositoryPath,
)
from patchharbor.patch_manifest import PatchManifest
from patchharbor.registry import load_registry
from patchharbor.repository import inspect_local_registration, inspect_repository_root
from patchharbor.result_bundle_handoff import create_result_handoff
from patchharbor.result_bundle_capture import capture_result_bundle
from patchharbor.result_resources import (
    PinnedResultResources, ResultRuntimePayload, capture_result_resources,
    runtime_fits, runtime_payload,
)
from patchharbor.result_bundle_publication import (
    PublicationDurability,
    PublishedResultBundle,
    ResultBundlePublication,
    prepare_result_bundle_publication,
    publish_result_bundle,
    result_bundle_filename,
)
from patchharbor.result_bundle_snapshot import ResultBundleSnapshot
from patchharbor.result_verification import ResultVerificationError
from patchharbor.result_bundle_target import (
    ResultBundleTarget,
    prepare_result_bundle_target,
    revalidate_result_bundle_target,
)
from patchharbor.run_report import (
    ApplyPrimaryOutcome,
    PrimaryResult,
    ResultBundleResult,
    RunOperation,
    RunReport,
    RunSession,
)
from patchharbor.temporary_resources import (
    create_private_request_directory,
    remove_private_request_directory,
)
from patchharbor.user_paths import registration_user_paths


_RESULT_MARKER = "patch-harbor-result-bundle"
_RESULT_FORMAT_VERSION = 2


@dataclass(frozen=True)
class ManualResultBundle:
    """One successfully created manual Result Bundle."""

    report: RunReport
    publication_durability: PublicationDurability

    @property
    def run_id(self) -> UUID:
        return self.report.run_id

    @property
    def context(self) -> RepositoryContext:
        context = self.report.context
        if context is None:
            raise RuntimeError("successful manual bundle has no repository context")
        return context

    @property
    def path(self) -> Path:
        path = self.report.result_bundle.path
        if path is None:
            raise RuntimeError("successful manual bundle has no published path")
        return path


def _create_private_run_directory(run_id: UUID) -> Path:
    """Create one private per-run diagnostics directory in the system temp."""
    return create_private_request_directory(name=f"patchharbor-{run_id}")


def _write_run_document(
    run_directory: Path,
    report: RunReport,
) -> None:
    """Atomically store one structured run report in the private run directory."""
    payload = serialize_json_document(report.as_run_document()).encode("utf-8")
    destination = run_directory / "run.json"
    temporary = run_directory / ".run.json.tmp"
    try:
        with temporary.open("xb") as stream:
            stream.write(payload)
            stream.flush()
        os.replace(temporary, destination)
    finally:
        try:
            temporary.unlink(missing_ok=True)
        except OSError:
            pass


def _write_execution_log(run_directory: Path, content: bytes) -> None:
    """Atomically store the byte-exact merged entrypoint output."""
    destination = run_directory / "execution.log"
    temporary = run_directory / ".execution.log.tmp"
    try:
        with temporary.open("xb") as stream:
            stream.write(content)
            stream.flush()
        os.replace(temporary, destination)
    finally:
        try:
            temporary.unlink(missing_ok=True)
        except OSError:
            pass


def _remove_private_run_directory(run_directory: Path) -> None:
    remove_private_request_directory(run_directory)


def _require_registered_mapping(
    snapshot: RegistrySnapshot,
    repo_id: RepositoryId,
    repository: RepositoryPath,
) -> None:
    id_matches = tuple(
        mapping for mapping in snapshot.repositories if mapping.repo_id == repo_id
    )
    path_matches = tuple(
        mapping
        for mapping in snapshot.repositories
        if mapping.repository_path == repository
    )
    if len(id_matches) != 1 or id_matches[0].repository_path != repository:
        raise repository_resolution_error(
            "repository identity is not registered for this path"
        )
    if len(path_matches) != 1 or path_matches[0].repo_id != repo_id:
        raise repository_resolution_error(
            "repository path has conflicting registrations"
        )


def _registered_identity(
    snapshot: RegistrySnapshot,
    repository: RepositoryPath,
) -> RepositoryId:
    repo_id, _ = inspect_local_registration(repository)
    if repo_id is None:
        raise repository_resolution_error(
            "repository has no local PatchHarbor identity"
        )
    _require_registered_mapping(snapshot, repo_id, repository)
    return repo_id


def _manifest_document(
    *,
    report: RunReport,
    snapshot: ResultBundleSnapshot,
    runtime: ResultRuntimePayload,
    expected_manifest: PatchManifest | None = None,
) -> dict[str, object]:
    context = report.context
    if context is None:
        raise ValueError("successful Result Bundle report has no context")
    document: dict[str, object] = {
        "marker": _RESULT_MARKER,
        "format_version": _RESULT_FORMAT_VERSION,
        "created_at": report.timing.started_at_text,
        "run_id": report.run_id_text,
        "repo_id": str(context.repo_id),
        "base_commit": str(context.base_commit),
        "state_fingerprint": context.state_fingerprint,
        "fingerprint_algorithm": context.fingerprint_algorithm,
        "dirty": context.dirty,
        "dry_run": report.dry_run,
        "entrypoint_started": report.primary_result.entrypoint_started,
        "execution_present": report.execution_present,
        "primary_result": report.primary_result.kind_text,
        "result_bundle_status": report.result_bundle.status_text,
        "runtime": runtime.document(),
        **snapshot.manifest_entries(),
    }
    if expected_manifest is not None:
        document.update(
            {
                "expected_base_commit": str(expected_manifest.base_commit),
                "actual_base_commit": str(context.base_commit),
                "expected_state_fingerprint": (
                    expected_manifest.state_fingerprint
                ),
                "actual_state_fingerprint": context.state_fingerprint,
                "expected_fingerprint_algorithm": (
                    expected_manifest.fingerprint_algorithm
                ),
                "actual_fingerprint_algorithm": (
                    context.fingerprint_algorithm
                ),
            }
        )
    return document


@dataclass(frozen=True, slots=True)
class _ResultDocuments:
    report: RunReport
    handoff: BundleHandoff
    manifest: dict[str, object]
    context: dict[str, object]
    runtime: ResultRuntimePayload


def _publication_documents(
    report: RunReport, target: ResultBundleTarget, snapshot: ResultBundleSnapshot,
    resources: PinnedResultResources, *, expected_manifest: PatchManifest | None = None,
    receipt: dict[str, object] | None = None, execution_log: bytes | None = None,
) -> _ResultDocuments:
    """Choose a complete runtime payload before opening the publication ZIP."""
    handoff = create_result_handoff(report, target, template=resources.require_template())
    context = _context_document(report, bundle_suffix=target.bundle_suffix)

    def assemble(runtime: ResultRuntimePayload) -> _ResultDocuments:
        completed = replace(report, warnings=tuple(dict.fromkeys((*report.warnings, *runtime.warnings))))
        manifest = _manifest_document(report=completed, snapshot=snapshot, runtime=runtime,
                                      expected_manifest=expected_manifest)
        if receipt is not None:
            manifest.update(receipt)
        return _ResultDocuments(completed, handoff, manifest, context, runtime)

    documents = assemble(resources.runtime)
    if resources.runtime.status == "embedded" and not runtime_fits(
        documents.runtime, manifest=documents.manifest, context_document=context,
        handoff=handoff, run_report=documents.report, snapshot=snapshot, execution_log=execution_log,
    ):
        documents = assemble(runtime_payload(None, reason="resource_limit"))
    return documents


def _publish_documents(
    publication: ResultBundlePublication, documents: _ResultDocuments,
    snapshot: ResultBundleSnapshot, run_directory: Path, *, execution_log: bytes | None = None,
    before_publish: Callable[[str], None] | None = None,
) -> PublishedResultBundle:
    """Publish the same prepared document set for manual and Apply requests."""
    _write_run_document(run_directory, documents.report)
    try:
        return publish_result_bundle(
            publication, manifest=documents.manifest, context_document=documents.context,
            run_report=documents.report, handoff=documents.handoff, snapshot=snapshot,
            runtime=documents.runtime, execution_log=execution_log, before_publish=before_publish,
        )
    except ResultVerificationError as exc:
        # Keep the versioned Result/run schemas unchanged. The existing error
        # string carries the classification; emergency evidence adds safe detail.
        try:
            with (run_directory / "verification.json").open("x", encoding="utf-8") as stream:
                json.dump(exc.diagnostics, stream, ensure_ascii=True, indent=2)
                stream.write("\n")
        except OSError:
            pass  # Diagnostic storage must never replace the original failure.
        raise


def _context_document(
    report: RunReport, *, bundle_suffix: str = "",
) -> dict[str, object]:
    context = report.context
    if context is None:
        raise ValueError("successful Result Bundle report has no context")
    return {
        "repo_id": str(context.repo_id),
        "base_commit": str(context.base_commit),
        "dirty": context.dirty,
        "state_fingerprint": context.state_fingerprint,
        "fingerprint_algorithm": context.fingerprint_algorithm,
        "created_at": report.timing.started_at_text,
        "bundle_suffix": bundle_suffix,
    }


def _preserve_emergency_diagnostics(
    run_directory: Path,
    report: RunReport,
) -> tuple[Path | None, bool]:
    """Best-effort preserve run.json and report whether rescue itself failed."""
    try:
        _write_run_document(run_directory, report)
        return run_directory.resolve(strict=True), False
    except (OSError, RuntimeError, TypeError, ValueError):
        _remove_private_run_directory(run_directory)
        return None, True


def _manual_bundle_failure(
    error: PatchHarborError,
    *,
    session: RunSession,
    run_directory: Path,
    context: RepositoryContext | None,
    repository: RepositoryPath | None,
    repo_id: RepositoryId | None,
) -> PatchHarborError:
    repository_resolved = repository is not None and repo_id is not None
    bundle_result = (
        ResultBundleResult.failed(str(error))
        if repository_resolved
        else ResultBundleResult.not_attempted(str(error))
    )
    report = RunReport(
        timing=session.finish(),
        operation=RunOperation.BUNDLE,
        dry_run=False,
        context=context,
        repository=repository,
        repo_id=repo_id,
        warnings=(),
        primary_result=PrimaryResult.from_tool_error(error),
        result_bundle=bundle_result,
    )
    emergency_path, rescue_failed = _preserve_emergency_diagnostics(
        run_directory,
        report,
    )
    report = report.with_result_bundle(
        report.result_bundle.with_emergency_diagnostics(emergency_path)
    )
    return PatchHarborError(
        str(error),
        FailureReason.RESULT_BUNDLE_ERROR,
        error_kind=error.error_kind,
        emergency_diagnostics_path=emergency_path,
        emergency_diagnostics_failed=rescue_failed,
        run_report=report,
    )


def _apply_report(
    *,
    session: RunSession,
    dry_run: bool,
    repository: RepositoryPath,
    repo_id: RepositoryId,
    context: RepositoryContext,
    warnings: tuple[str, ...],
    primary_outcome: ApplyPrimaryOutcome,
    result_bundle: ResultBundleResult,
) -> RunReport:
    return RunReport.completed_apply(
        timing=session.finish(),
        dry_run=dry_run,
        context=context,
        repository=repository,
        repo_id=repo_id,
        warnings=warnings,
        primary_outcome=primary_outcome,
        result_bundle=result_bundle,
    )


def create_apply_result_bundle(
    repository: RepositoryPath,
    repo_id: RepositoryId,
    registry_snapshot: RegistrySnapshot,
    actual_context: RepositoryContext,
    expected_manifest: PatchManifest,
    *,
    target: ResultBundleTarget,
    publication: ResultBundlePublication,
    warnings: tuple[str, ...],
    session: RunSession,
    dry_run: bool,
    primary_outcome: ApplyPrimaryOutcome,
    resources: PinnedResultResources,
    execution_log: bytes | None = None,
    package_sha256: str | None = None,
    before_publish: Callable[[str], None] | None = None,
) -> RunReport:
    """Attempt one apply Result Bundle while the repository lock is held."""
    paths = registration_user_paths()
    try:
        run_directory = _create_private_run_directory(session.run_id)
    except (OSError, RuntimeError):
        return _apply_report(
            session=session,
            dry_run=dry_run,
            repository=repository,
            repo_id=repo_id,
            context=actual_context,
            warnings=warnings,
            primary_outcome=primary_outcome,
            result_bundle=ResultBundleResult.failed(
                "cannot create emergency diagnostics for the Result Bundle"
            ),
        )

    diagnostic_context = actual_context
    try:
        if execution_log is not None:
            _write_execution_log(run_directory, execution_log)
        captured = capture_result_bundle(repository, repo_id)
        diagnostic_context = captured.context
        revalidate_result_bundle_target(target, registry_snapshot)
        report = _apply_report(
            session=session,
            dry_run=dry_run,
            repository=repository,
            repo_id=repo_id,
            context=captured.context,
            warnings=warnings,
            primary_outcome=primary_outcome,
            result_bundle=ResultBundleResult.created(target.final_path),
        )
        completed_commit = None
        if (package_sha256 is not None and primary_outcome.result.success
            and report.execution_present and not dry_run
            and actual_context.base_commit == expected_manifest.base_commit):
            try:
                completed_commit = completed_commit_for_context(actual_context, captured.context)
            except (PatchHarborError, OSError, ValueError):
                pass  # A success/no-op is not automatically a committed success.
        receipt = (None if package_sha256 is None else
                   {"patch_sha256": package_sha256,
                    "completed_commit": str(completed_commit) if completed_commit else None})
        documents = _publication_documents(
            report, target, captured.bundle_snapshot, resources,
            expected_manifest=expected_manifest, receipt=receipt, execution_log=execution_log)
        report = documents.report
        warnings = report.warnings
        revalidate_result_bundle_target(target, registry_snapshot)
        _publish_documents(
            publication, documents, captured.bundle_snapshot, run_directory,
            before_publish=(before_publish if completed_commit is not None else None),
            execution_log=execution_log,
        )
    except PatchHarborError as exc:
        report = _apply_report(
            session=session,
            dry_run=dry_run,
            repository=repository,
            repo_id=repo_id,
            context=diagnostic_context,
            warnings=warnings,
            primary_outcome=primary_outcome,
            result_bundle=ResultBundleResult.failed(str(exc)),
        )
        emergency_path, rescue_failed = _preserve_emergency_diagnostics(
            run_directory,
            report,
        )
        if rescue_failed:
            return report
        return report.with_result_bundle(
            report.result_bundle.with_emergency_diagnostics(emergency_path)
        )
    except (OSError, RuntimeError, TypeError, ValueError):
        report = _apply_report(
            session=session,
            dry_run=dry_run,
            repository=repository,
            repo_id=repo_id,
            context=diagnostic_context,
            warnings=warnings,
            primary_outcome=primary_outcome,
            result_bundle=ResultBundleResult.failed(
                "cannot create the Result Bundle"
            ),
        )
        emergency_path, rescue_failed = _preserve_emergency_diagnostics(
            run_directory,
            report,
        )
        if rescue_failed:
            return report
        return report.with_result_bundle(
            report.result_bundle.with_emergency_diagnostics(emergency_path)
        )

    _remove_private_run_directory(run_directory)
    return report


def create_manual_result_bundle(
    path: Path,
    *,
    output_directory: Path | None = None,
) -> ManualResultBundle:
    """Create one Result Bundle for a registered supported repository."""
    session = RunSession.start()
    try:
        run_directory = _create_private_run_directory(session.run_id)
    except (OSError, RuntimeError) as exc:
        raise result_bundle_error(
            "cannot create emergency diagnostics for the Result Bundle",
            emergency_diagnostics_failed=True,
        ) from exc

    context: RepositoryContext | None = None
    resolved_repository: RepositoryPath | None = None
    resolved_repo_id: RepositoryId | None = None
    try:
        paths = registration_user_paths()
        with ExitStack() as repository_scope:
            with registry_lock(paths):
                registry_snapshot = load_registry(paths)
                repository = inspect_repository_root(path)
                repo_id = _registered_identity(registry_snapshot, repository)
                resolved_repository = repository
                resolved_repo_id = repo_id
                filename = result_bundle_filename(
                    session,
                    repository_name=repository.value.name,
                )
                target = prepare_result_bundle_target(
                    output_directory,
                    registry_snapshot,
                    configuration_paths_for_id(repo_id, registry_snapshot),
                    filename=filename,
                )
                repository_scope.enter_context(repository_lock(paths, repo_id))

                locked_repository = inspect_repository_root(repository.value)
                if locked_repository != repository:
                    raise repository_resolution_error(
                        "repository path changed while acquiring its lock"
                    )
                locked_registry = load_registry(paths)
                locked_id = _registered_identity(locked_registry, locked_repository)
                if locked_id != repo_id:
                    raise repository_resolution_error(
                        "repository identity changed while acquiring its lock"
                    )
                revalidate_result_bundle_target(target, locked_registry)

            resources = capture_result_resources()
            captured = capture_result_bundle(locked_repository, locked_id)
            revalidate_result_bundle_target(target, locked_registry)
            context = captured.context
            bundle_snapshot = captured.bundle_snapshot
            report = RunReport(
                timing=session.finish(),
                operation=RunOperation.BUNDLE,
                dry_run=False,
                context=context,
                repository=resolved_repository,
                repo_id=resolved_repo_id,
                warnings=(),
                primary_result=PrimaryResult.success_result(),
                result_bundle=ResultBundleResult.created(target.final_path),
            )
            documents = _publication_documents(
                report, target, bundle_snapshot, resources)
            report = documents.report
            revalidate_result_bundle_target(target, locked_registry)
            publication = prepare_result_bundle_publication(
                target.final_path,
                run_id=session.run_id,
            )
            published = _publish_documents(
                publication, documents, bundle_snapshot, run_directory,
            )
    except PatchHarborError as exc:
        raise _manual_bundle_failure(
            exc,
            session=session,
            run_directory=run_directory,
            context=context,
            repository=resolved_repository,
            repo_id=resolved_repo_id,
        ) from exc
    except (OSError, RuntimeError, TypeError, ValueError) as exc:
        wrapped = result_bundle_error("cannot create the Result Bundle")
        raise _manual_bundle_failure(
            wrapped,
            session=session,
            run_directory=run_directory,
            context=context,
            repository=resolved_repository,
            repo_id=resolved_repo_id,
        ) from exc

    _remove_private_run_directory(run_directory)
    return ManualResultBundle(
        report=report,
        publication_durability=published.durability,
    )
