"""Filesystem adapter for portable target inspection and atomic replacement."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from enum import Enum, auto
from hashlib import sha256
import errno
import os
from pathlib import Path
import stat
import tempfile

from patchharbor.platform.runtime import is_windows
from patchharbor.platform.file_handles import open_regular_nofollow


class PathKind(Enum):
    """Portable kinds needed by PatchHarbor's file-writing policy."""

    MISSING = auto()
    REGULAR_FILE = auto()
    DIRECTORY = auto()
    SYMBOLIC_LINK = auto()
    JUNCTION = auto()
    OTHER = auto()


class MetadataSyncStatus(Enum):
    """Observed outcome of one best-effort metadata synchronization."""

    SYNCED = auto()
    UNSUPPORTED = auto()
    FAILED = auto()


class FileChangedDuringRead(RuntimeError):
    """A path no longer identifies the same regular file during one read."""

    def __init__(self, message: str = "", *, category: str = "unknown",
                 before: os.stat_result | None = None,
                 after: os.stat_result | None = None) -> None:
        super().__init__(message)
        if category not in {"unknown", "path-missing", "initial-open-state-mismatch",
                            "current-path-state-mismatch", "descriptor-state-changed",
                            "final-path-state-mismatch", "size-mismatch"}:
            raise ValueError("invalid stable-read mismatch category")
        self.category = category
        fields = ("st_dev", "st_ino", "st_mode", "st_size", "st_mtime_ns", "st_ctime_ns")
        self.metadata = {label: {name: getattr(value, name) for name in fields}
                         for label, value in (("before", before), ("after", after))
                         if value is not None}


class UnsupportedFileTypeError(RuntimeError):
    """A path at a regular-file boundary has an unsupported type."""


class FileReadLimitExceeded(ValueError):
    """A bounded file read exceeded its input budget, including during growth."""


@dataclass(frozen=True, slots=True)
class StableRegularFile:
    """Byte-exact content and portable executable state of one stable file."""

    content: bytes
    executable: bool


@dataclass(frozen=True, slots=True)
class StableRegularFileHash:
    """Stable full-file identity with content retained only below one limit."""

    content: bytes | None
    executable: bool
    size: int
    mtime_ns: int
    sha256: str


class FileSystemOperationError(OSError):
    """One filesystem operation failed below the platform-neutral policy."""

    def __init__(self, operation: str, cause: OSError) -> None:
        super().__init__(operation)
        self.operation = operation
        self.cause = cause


def path_kind(path: Path) -> PathKind:
    """Inspect one path without following symbolic links."""
    try:
        mode = path.lstat().st_mode
    except FileNotFoundError:
        return PathKind.MISSING
    except OSError as exc:
        raise FileSystemOperationError("cannot inspect target", exc) from exc

    junction_check = getattr(path, "is_junction", None)
    try:
        if callable(junction_check) and junction_check():
            return PathKind.JUNCTION
    except OSError as exc:
        raise FileSystemOperationError("cannot inspect target", exc) from exc

    if stat.S_ISLNK(mode):
        return PathKind.SYMBOLIC_LINK
    if stat.S_ISREG(mode):
        return PathKind.REGULAR_FILE
    if stat.S_ISDIR(mode):
        return PathKind.DIRECTORY
    return PathKind.OTHER


def create_directory(path: Path) -> None:
    """Create exactly one directory and expose a stable operation failure."""
    try:
        path.mkdir()
    except OSError as exc:
        raise FileSystemOperationError(
            "cannot create parent directory",
            exc,
        ) from exc


@dataclass(frozen=True, slots=True)
class RegularFileState:
    """Observed identity/change signature and optional native POSIX mode."""

    signature: tuple[int, ...]
    mode: int | None


def regular_file_state(path: Path) -> RegularFileState | None:
    """Capture one regular target without following links; None means absent."""
    try:
        metadata = path.lstat()
    except FileNotFoundError:
        return None
    except OSError as exc:
        raise FileSystemOperationError("cannot inspect target mode", exc) from exc
    if not stat.S_ISREG(metadata.st_mode):
        raise FileSystemOperationError(
            "target is not a regular file", OSError(errno.EINVAL, "unsupported target")
        )
    return RegularFileState(
        signature=(metadata.st_dev, metadata.st_ino, metadata.st_mode,
                   metadata.st_size, metadata.st_mtime_ns, metadata.st_ctime_ns),
        mode=None if is_windows() else stat.S_IMODE(metadata.st_mode),
    )


def atomic_replace_bytes(
    target: Path, content: bytes, *, mode: int | None = None,
    before_replace: Callable[[], None] | None = None,
) -> None:
    """Publish bytes atomically; optionally set POSIX mode before replacement.

    No mode means the unchanged private temporary-file policy. Windows does
    not emulate Unix permission bits or change ACLs based on ZIP metadata.
    """
    staged_path: Path | None = None
    try:
        try:
            with tempfile.NamedTemporaryFile(
                mode="wb",
                dir=target.parent,
                prefix=".patchharbor-",
                suffix=".tmp",
                delete=False,
            ) as handle:
                staged_path = Path(handle.name)
                handle.write(content)
                handle.flush()
                if mode is not None and not is_windows():
                    os.fchmod(handle.fileno(), mode)
                os.fsync(handle.fileno())
        except OSError as exc:
            raise FileSystemOperationError(
                "cannot stage replacement",
                exc,
            ) from exc

        if before_replace is not None:
            before_replace()
        try:
            os.replace(staged_path, target)
        except OSError as exc:
            raise FileSystemOperationError(
                "cannot replace target",
                exc,
            ) from exc
        staged_path = None
    finally:
        if staged_path is not None:
            try:
                staged_path.unlink(missing_ok=True)
            except OSError:
                pass


def _path_and_descriptor_signature(metadata: os.stat_result) -> tuple[int, ...]:
    common = (
        stat.S_IFMT(metadata.st_mode),
        metadata.st_size,
        metadata.st_mtime_ns,
    )
    if is_windows():
        # Windows path stat and descriptor fstat expose different ctime
        # semantics; birth time is stable across both views of one file.
        return (*common, metadata.st_birthtime_ns)
    return (*common, stat.S_IMODE(metadata.st_mode), metadata.st_ctime_ns)


def _descriptor_signature(metadata: os.stat_result) -> tuple[int, ...]:
    common = _path_and_descriptor_signature(metadata)
    if is_windows():
        # Descriptor ctime is the Windows change time and catches mutation
        # while the file remains open.
        return (*common, metadata.st_ctime_ns)
    return common


def _portable_content_signature(metadata: os.stat_result) -> tuple[int, ...]:
    """Metadata that path and descriptor views should expose consistently."""
    return (
        stat.S_IFMT(metadata.st_mode),
        metadata.st_size,
        metadata.st_mtime_ns,
    )


def _same_path_and_open_file_state(
    path_metadata: os.stat_result,
    opened_metadata: os.stat_result,
    *,
    allow_path_identity_fallback: bool,
) -> bool:
    if os.path.samestat(path_metadata, opened_metadata) and (
        _path_and_descriptor_signature(path_metadata)
        == _path_and_descriptor_signature(opened_metadata)
    ):
        return True
    return allow_path_identity_fallback and (
        _portable_content_signature(path_metadata)
        == _portable_content_signature(opened_metadata)
    )


def _same_open_file_state(
    first: os.stat_result,
    second: os.stat_result,
) -> bool:
    return os.path.samestat(first, second) and (
        _descriptor_signature(first) == _descriptor_signature(second)
    )


def _inspect_path_without_following(path: Path) -> os.stat_result | None:
    try:
        return path.lstat()
    except FileNotFoundError:
        return None
    except OSError as exc:
        raise FileSystemOperationError("cannot inspect target", exc) from exc


def _require_regular_file(metadata: os.stat_result) -> None:
    if not stat.S_ISREG(metadata.st_mode):
        raise UnsupportedFileTypeError


def _regular_path_metadata(path: Path) -> os.stat_result:
    metadata = _inspect_path_without_following(path)
    if metadata is None:
        raise FileChangedDuringRead(category="path-missing")
    _require_regular_file(metadata)
    return metadata


def require_file_identity(metadata: os.stat_result, expected: os.stat_result) -> None:
    """Ownership mismatches are terminal, never metadata stabilization retries."""
    if not stat.S_ISREG(metadata.st_mode) or not os.path.samestat(metadata, expected):
        raise FileSystemOperationError("owned file identity changed", OSError(errno.EINVAL, "identity mismatch"))


def _read_stable_regular_file(
    path: Path,
    *,
    retained_content_limit: int | None,
    calculate_sha256: bool,
    allow_path_identity_fallback: bool,
    max_bytes: int | None = None,
    expected_identity: os.stat_result | None = None,
) -> tuple[bytes | None, bool, int, int, str | None]:
    initial_metadata = _regular_path_metadata(path)
    if expected_identity is not None:
        require_file_identity(initial_metadata, expected_identity)
    if max_bytes is not None and initial_metadata.st_size > max_bytes:
        raise FileReadLimitExceeded("regular file exceeds read budget")

    flags = os.O_RDONLY
    flags |= getattr(os, "O_BINARY", 0)
    flags |= getattr(os, "O_CLOEXEC", 0)
    flags |= getattr(os, "O_NOFOLLOW", 0)
    if max_bytes is not None:
        flags |= getattr(os, "O_NONBLOCK", 0)

    descriptor: int | None = None
    try:
        descriptor = (os.open(path, flags) if expected_identity is None
                      else open_regular_nofollow(path))
        opened_metadata = os.fstat(descriptor)
        _require_regular_file(opened_metadata)
        if expected_identity is not None:
            require_file_identity(opened_metadata, expected_identity)
        if not _same_path_and_open_file_state(
            initial_metadata,
            opened_metadata,
            allow_path_identity_fallback=allow_path_identity_fallback,
        ):
            raise FileChangedDuringRead(category="initial-open-state-mismatch",
                                        before=initial_metadata, after=opened_metadata)

        current_metadata = _regular_path_metadata(path)
        if expected_identity is not None:
            require_file_identity(current_metadata, expected_identity)
        if not _same_path_and_open_file_state(
            current_metadata,
            opened_metadata,
            allow_path_identity_fallback=allow_path_identity_fallback,
        ):
            raise FileChangedDuringRead(category="current-path-state-mismatch",
                                        before=current_metadata, after=opened_metadata)

        hasher = sha256() if calculate_sha256 else None
        retained: bytearray | None = bytearray()
        size = 0
        with os.fdopen(descriptor, "rb", closefd=True) as handle:
            descriptor = None
            while chunk := handle.read(1024 * 1024 if max_bytes is None else
                                       min(1024 * 1024, max_bytes - size + 1)):
                size += len(chunk)
                if max_bytes is not None and size > max_bytes:
                    raise FileReadLimitExceeded("regular file grew beyond read budget")
                if hasher is not None:
                    hasher.update(chunk)
                if retained is not None:
                    if (
                        retained_content_limit is None
                        or size <= retained_content_limit
                    ):
                        retained.extend(chunk)
                    else:
                        retained = None
            finished_metadata = os.fstat(handle.fileno())
    except (FileChangedDuringRead, UnsupportedFileTypeError):
        raise
    except OSError as exc:
        raise FileSystemOperationError("cannot read target", exc) from exc
    finally:
        if descriptor is not None:
            try:
                os.close(descriptor)
            except OSError:
                pass

    final_metadata = _regular_path_metadata(path)
    if expected_identity is not None:
        require_file_identity(final_metadata, expected_identity)
    if not _same_open_file_state(opened_metadata, finished_metadata):
        raise FileChangedDuringRead(category="descriptor-state-changed",
                                    before=opened_metadata, after=finished_metadata)
    if not _same_path_and_open_file_state(
        final_metadata, finished_metadata,
        allow_path_identity_fallback=allow_path_identity_fallback,
    ):
        raise FileChangedDuringRead(category="final-path-state-mismatch",
                                    before=finished_metadata, after=final_metadata)
    if size != finished_metadata.st_size:
        raise FileChangedDuringRead(category="size-mismatch")

    return (
        bytes(retained) if retained is not None else None,
        bool(finished_metadata.st_mode & 0o111),
        size,
        finished_metadata.st_mtime_ns,
        hasher.hexdigest() if hasher is not None else None,
    )


def read_stable_regular_file(path: Path) -> StableRegularFile:
    """Read one regular file without following links and reject path races."""
    content, executable, _size, _mtime_ns, _digest = _read_stable_regular_file(
        path,
        retained_content_limit=None,
        calculate_sha256=False,
        allow_path_identity_fallback=False,
    )
    if content is None:
        raise RuntimeError("unlimited stable file read discarded its content")
    return StableRegularFile(content=content, executable=executable)


def read_stable_regular_file_bounded(path: Path, *, max_bytes: int) -> StableRegularFile:
    """Reuse native identity/race checks, reading at most budget + one byte."""
    if type(max_bytes) is not int or max_bytes < 0:
        raise ValueError("max_bytes must be a non-negative integer")
    content, executable, _size, _mtime, _digest = _read_stable_regular_file(
        path, retained_content_limit=None, calculate_sha256=False,
        allow_path_identity_fallback=False, max_bytes=max_bytes,
    )
    if content is None:
        raise RuntimeError("bounded read discarded retained content")
    return StableRegularFile(content, executable)


def read_stable_regular_file_with_sha256(
    path: Path,
    *,
    retained_content_limit: int,
    allow_path_identity_fallback: bool = False,
    expected_identity: os.stat_result | None = None,
    max_bytes: int | None = None,
) -> StableRegularFileHash:
    """Hash a stable regular file while bounding retained in-memory content.

    The opt-in fallback accepts matching type, size, and mtime when a virtual
    filesystem does not expose comparable path and descriptor identities. It
    remains unsuitable as a sole trust decision and is reserved for callers
    that subsequently re-open and verify the complete content hash.
    """
    if max_bytes is not None and (type(max_bytes) is not int or max_bytes < 0):
        raise ValueError("max_bytes must be a non-negative integer")
    if (
        isinstance(retained_content_limit, bool)
        or not isinstance(retained_content_limit, int)
        or retained_content_limit <= 0
    ):
        raise ValueError("retained_content_limit must be a positive integer")
    content, executable, size, mtime_ns, digest = _read_stable_regular_file(
        path,
        retained_content_limit=retained_content_limit,
        calculate_sha256=True,
        allow_path_identity_fallback=allow_path_identity_fallback,
        expected_identity=expected_identity,
        max_bytes=max_bytes,
    )
    if digest is None:
        raise RuntimeError("stable hashed file read did not produce a digest")
    return StableRegularFileHash(
        content=content,
        executable=executable,
        size=size,
        mtime_ns=mtime_ns,
        sha256=digest,
    )


_UNSUPPORTED_SYNC_ERRNOS = frozenset(
    error_number
    for error_number in (
        errno.EBADF,
        errno.EINVAL,
        getattr(errno, "ENOTSUP", None),
        getattr(errno, "EOPNOTSUPP", None),
    )
    if error_number is not None
)


def _sync_descriptor_best_effort(
    path: Path,
    *,
    directory: bool,
    expected_identity: os.stat_result | None = None,
) -> MetadataSyncStatus:
    if directory and is_windows():
        return MetadataSyncStatus.UNSUPPORTED

    flags = os.O_RDONLY | getattr(os, "O_BINARY", 0) | getattr(os, "O_NOFOLLOW", 0)
    if directory:
        flags |= getattr(os, "O_DIRECTORY", 0)
    try:
        descriptor = (os.open(path, flags) if expected_identity is None
                      else open_regular_nofollow(path, writable=is_windows()))
    except OSError:
        if expected_identity is not None:
            raise
        return MetadataSyncStatus.FAILED

    status = MetadataSyncStatus.SYNCED
    try:
        if expected_identity is not None:
            require_file_identity(os.fstat(descriptor), expected_identity)
            require_file_identity(path.lstat(), expected_identity)
        try:
            os.fsync(descriptor)
        except OSError as exc:
            status = (
                MetadataSyncStatus.UNSUPPORTED
                if exc.errno in _UNSUPPORTED_SYNC_ERRNOS
                else MetadataSyncStatus.FAILED
            )
        if expected_identity is not None:
            require_file_identity(path.lstat(), expected_identity)
    finally:
        try:
            os.close(descriptor)
        except OSError:
            if status is MetadataSyncStatus.SYNCED:
                status = MetadataSyncStatus.FAILED
    return status


def sync_regular_file_best_effort(
    path: Path, *, expected_identity: os.stat_result | None = None,
) -> MetadataSyncStatus:
    """Try to synchronize one closed regular file without promising durability."""
    return _sync_descriptor_best_effort(path, directory=False, expected_identity=expected_identity)


def sync_directory_best_effort(path: Path) -> MetadataSyncStatus:
    """Try to synchronize directory metadata where the platform supports it."""
    return _sync_descriptor_best_effort(path, directory=True)


def replace_path(source: Path, target: Path) -> None:
    """Atomically replace one path and expose a stable operation failure."""
    try:
        os.replace(source, target)
    except OSError as exc:
        raise FileSystemOperationError("cannot replace target", exc) from exc
