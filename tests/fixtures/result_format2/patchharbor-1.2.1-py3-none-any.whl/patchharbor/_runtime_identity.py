# Generated at wheel build; no runtime work.
RESOURCE_ID = "c2d3d387c4c03a8be36bde7b7cf9db492bdb4d84981f4acd5247b594c158abba"
