"""Application orchestration for one PatchHarbor runner request."""

from __future__ import annotations

from collections.abc import Callable, Iterator
from contextlib import ExitStack, contextmanager
from dataclasses import dataclass, replace
from pathlib import Path
import stat
import unicodedata
from typing import TextIO

from patchharbor.progress import (
    PackageFile, RepositoryResolved, RequestStarted, ScriptPrepared, activity, emit,
)

from patchharbor.apply_mutation import (
    ApplyMutationGate,
    MutationFailureKind,
    apply_payload_mutation,
)
from patchharbor.apply_preflight import prepare_patch_package
from patchharbor.apply_repository import (
    SafeResolvedRepository,
    safely_resolved_repository,
)
from patchharbor.archive_git import completed_commit_for_context
from patchharbor.archive_policy import validate_archive_directory
from patchharbor.exchange_archive import archive_exchange_artifacts
from patchharbor.exchange_recovery import recover_exchange_artifacts
from patchharbor.bundle_names import validate_bundle_suffix
from patchharbor.bundles import resolve_patch_bundle
from patchharbor.configuration import (
    RepositoryConfiguration, RepositoryConfigurationPaths,
    load_configuration,
    prepare_exchange_directory,
    resolve_exchange_directory_candidate,
    revalidate_exchange_directory,
    write_prepared_configuration,
)
from patchharbor.configuration_context import (
    configuration_paths_for_id, configuration_paths_for_repository,
)
from patchharbor.errors import (
    ErrorKind,
    FailureReason,
    PatchHarborError,
    LockBusyError,
    NoEligiblePatchError,
    configuration_error,
    patch_package_error,
    registry_error,
    repository_resolution_error,
    state_mismatch_error,
)
from patchharbor.exchange import (
    ExchangeArtifact,
    ExchangeArtifactKind,
    ExchangeScanError,
    materialize_exchange_patch,
    require_exchange_identity_unchanged,
    scan_exchange_directory,
)
from patchharbor.exchange_state import (
    _state_lock,
    ExchangeApplyStatus,
    ExchangePatchSelection,
    mark_exchange_apply_finished,
    mark_exchange_apply_started,
    record_exchange_result_digest,
)
from patchharbor.exchange_paths import (
    ExchangePathPolicyError,
    require_exchange_outside_registry,
)
from patchharbor.execution import (
    DEFAULT_TIMEOUT_SECONDS,
    ScriptExecutionResult,
    execute_prepared_script_with_log,
    execute_script_text,
)
from patchharbor.locks import registry_lock, repository_lock
from patchharbor.models import (
    BundleScript,
    GitObjectId,
    InputArtifact,
    RegistryListResult,
    RegistrySnapshot, RegistryStatus,
    RepositoryContext,
    RepositoryId,
    RepositoryPath,
)
from patchharbor.output import OutputTargets
from patchharbor.parser import parse_script
from patchharbor.patch_manifest import PatchManifest
from patchharbor.patch_inspection import (
    PatchInspection, PatchValidationResult,
    inspect_patch as _inspect_patch, validate_patch as _validate_patch,
)
from patchharbor.patch_package import (
    ValidatedPatchPackage,
    resolve_patch_package as _resolve_patch_package,
    validate_patch_package as _validate_patch_package,
)
from patchharbor.payload_files import (
    validate_bundle_payload_targets,
    write_bundle_payloads,
)
from patchharbor.registration import (
    list_registered_repositories,
    register_local_repository,
    unregister_local_repository,
)
from patchharbor.registry import load_registry
from patchharbor.repository import registered_repository_status
from patchharbor.repository_state import (
    capture_consistent_repository_snapshot,
    repository_context_from_snapshot,
    capture_repository_context,
    capture_repository_context_for_id,
    require_clean_repository,
)
from patchharbor.resource_policy import DEFAULT_RESOURCE_POLICY, ResourcePolicy
from patchharbor.result_bundle import (
    ManualResultBundle,
    create_apply_result_bundle,
    create_manual_result_bundle,
)
from patchharbor.result_resources import PinnedResultResources, capture_result_resources
from patchharbor.run_report import (
    ApplyPrimaryOutcome,
    RunReport,
    RunSession,
    unresolved_apply_report,
)
from patchharbor.sources import (
    DirectoryCandidate,
    file_input_artifact,
    list_directory_entries,
    stdin_input_artifact,
)
from patchharbor.user_paths import (
    RegistrationUserPaths,
    configuration_user_paths,
    registration_user_paths,
)
from patchharbor.watch_contract import (
    ApplyLock, ApplyLockKind, ApplyReadiness, AutomaticApplyResult,
    AutomaticApplyStatus, ExchangeWatchTarget, WatchControlPaths, WatchTargets,
)


def _require_exchange_configuration_allowed(
    exchange_directory: Path,
    registry_snapshot: RegistrySnapshot,
    *,
    exchange_must_exist: bool,
) -> None:
    try:
        require_exchange_outside_registry(
            exchange_directory,
            registry_snapshot,
            exchange_must_exist=exchange_must_exist,
        )
    except ExchangePathPolicyError as exc:
        raise configuration_error(str(exc)) from exc


def _change_repository_configuration(
    repository: Path,
    change: Callable[[RepositoryConfigurationPaths, RepositoryConfiguration, RegistrySnapshot], RepositoryConfiguration],
) -> tuple[Path, RepositoryConfiguration]:
    """Serialize local setting updates with registration and running Apply."""
    paths = configuration_user_paths()
    with registry_lock(paths):
        expected_registry = load_registry(paths)
        local = configuration_paths_for_repository(repository, expected_registry)
        with repository_lock(paths, local.repo_id):
            previous = load_configuration(local, validate_directory=False)
            updated = change(local, previous, expected_registry)
            if load_registry(paths) != expected_registry:
                raise registry_error("repository registry changed while configuring exchange directory")
            if configuration_paths_for_repository(repository, expected_registry) != local:
                raise repository_resolution_error("repository identity changed while configuring")
            if load_configuration(local, validate_directory=False) != previous:
                raise configuration_error("repository configuration changed while configuring")
            if updated.exchange_directory is not None:
                revalidate_exchange_directory(updated)
                _require_exchange_configuration_allowed(
                    updated.exchange_directory, expected_registry, exchange_must_exist=True,
                )
            return local.configuration_path, write_prepared_configuration(local, updated)


def configure_exchange_directory(
    path: Path, *, repository: Path = Path("."),
) -> tuple[Path, RepositoryConfiguration]:
    """Persist the current (or explicitly selected API) repository's Exchange."""
    def change(local, previous, registry):
        candidate = resolve_exchange_directory_candidate(path)
        _require_exchange_configuration_allowed(candidate, registry, exchange_must_exist=False)
        return prepare_exchange_directory(local, path)
    return _change_repository_configuration(repository, change)


def configure_bundle_suffix(
    suffix: str, *, repository: Path = Path("."),
) -> tuple[Path, RepositoryConfiguration]:
    """Change this repository's suffix, including before Exchange is configured."""
    try:
        suffix = validate_bundle_suffix(suffix)
    except ValueError as exc:
        raise configuration_error(str(exc)) from exc
    return _change_repository_configuration(
        repository, lambda local, previous, registry: replace(previous, bundle_suffix=suffix),
    )


def configure_archive_directory(
    name: str, *, repository: Path = Path("."),
) -> tuple[Path, RepositoryConfiguration]:
    """Change this repository's archive child name; empty means disabled."""
    try:
        name = validate_archive_directory(name)
    except ValueError as exc:
        raise configuration_error(str(exc)) from exc
    return _change_repository_configuration(
        repository, lambda local, previous, registry: replace(previous, archive_directory=name),
    )


def repository_configuration(
    repository: Path = Path("."), *, revalidate: bool = False,
) -> tuple[Path, RepositoryConfiguration]:
    """Read only the selected registered repository's valid local settings."""
    paths = configuration_user_paths()
    with registry_lock(paths):
        registry = load_registry(paths)
        local = configuration_paths_for_repository(repository, registry)
        configuration = load_configuration(local, validate_directory=False)
        if revalidate:
            revalidate_exchange_directory(configuration)
            _require_exchange_configuration_allowed(
                configuration.exchange_directory, registry, exchange_must_exist=True,
            )
        return local.configuration_path, configuration


def resolve_patch_package(
    path: Path,
    *,
    resource_policy: ResourcePolicy = DEFAULT_RESOURCE_POLICY,
) -> ValidatedPatchPackage:
    """Resolve one complete patch package through the package boundary."""
    return _resolve_patch_package(path, resource_policy=resource_policy)


def validate_patch_package(
    path: Path,
    *,
    resource_policy: ResourcePolicy = DEFAULT_RESOURCE_POLICY,
) -> PatchManifest:
    """Validate one complete patch package through the package boundary."""
    return _validate_patch_package(path, resource_policy=resource_policy)


def inspect_patch(path: Path) -> PatchInspection:
    """Read package facts without entering the Apply lifecycle."""
    return _inspect_patch(path)


def validate_patch(path: Path, *, repository: Path | None = None,
                   reference_bundle: Path | None = None) -> PatchValidationResult:
    """Validate an explicitly supplied package; no implicit repository selection."""
    return _validate_patch(path, repository=repository, reference_bundle=reference_bundle)


def _manifest_matches_context(
    manifest: PatchManifest,
    context: RepositoryContext,
) -> bool:
    return (
        manifest.repo_id == context.repo_id
        and manifest.base_commit == context.base_commit
        and manifest.fingerprint_algorithm == context.fingerprint_algorithm
        and manifest.state_fingerprint == context.state_fingerprint
    )


@dataclass(frozen=True, slots=True)
class DiscoveredExchangePatch:
    """One selected package plus its persistent attempt boundary."""

    artifact: ExchangeArtifact
    package: ValidatedPatchPackage
    paths: RegistrationUserPaths
    configuration: RepositoryConfiguration
    configuration_paths: RepositoryConfigurationPaths
    retry_failed: bool = False
    explicitly_selected: bool = False
    watch_target: ExchangeWatchTarget | None = None

    def __post_init__(self) -> None:
        if self.artifact.selection is None:
            raise ValueError("discovered Exchange patch requires selection data")
        expected_status = (
            ExchangeApplyStatus.FAILED if self.retry_failed else None
        )
        if not self.explicitly_selected and self.artifact.apply_status is not expected_status:
            raise ValueError(
                "discovered Exchange patch has an ineligible apply status"
            )
        if (
            self.artifact.selection
            != ExchangePatchSelection.from_manifest(self.package.manifest)
        ):
            raise ValueError("discovered Exchange package changed after selection")

    def publish_attempt(self, run_id: str | None = None) -> None:
        """Consume this identity immediately before repository mutation."""
        selection = self.artifact.selection
        if selection is None:
            raise RuntimeError("discovered Exchange patch lost selection data")

        def verify_identity() -> None:
            if self.watch_target is not None:
                _require_watch_target_unchanged(self.watch_target)
            current_configuration = revalidate_exchange_directory(
                load_configuration(self.configuration_paths)
            )
            if current_configuration != self.configuration:
                raise configuration_error(
                    "exchange directory changed before repository mutation"
                )
            require_exchange_identity_unchanged(
                self.artifact.identity,
                directory=self.configuration.exchange_directory,
            )
            if self.watch_target is not None:
                _require_watch_target_unchanged(self.watch_target)

        activity("REPLAY", f"Record attempted run {str(run_id)} before mutation", identifiers=(str(run_id),))
        mark_exchange_apply_started(
            self.paths,
            self.artifact.identity,
            selection,
            verify_identity=verify_identity,
            retry_failed=self.retry_failed,
            explicitly_selected=self.explicitly_selected,
            run_id=run_id,
        )

    def publish_result_digest(self, run_id: str, digest: str) -> None:
        """Persist a byte-exact result receipt before its final publication."""
        assert self.artifact.selection is not None
        activity("RECEIPT", f"Pin Result SHA-256 {str(digest)} "
                 f"for run {str(run_id)} before publication", identifiers=(str(digest), str(run_id),))
        record_exchange_result_digest(
            self.paths, self.artifact.identity, self.artifact.selection,
            run_id=run_id, result_sha256=digest,
        )

    def publish_outcome(self, succeeded: bool, completed_commit: GitObjectId | None = None,
                        *, run_id: str | None = None) -> None:
        """Persist the known terminal result of this started automatic apply."""
        selection = self.artifact.selection
        if selection is None:
            raise RuntimeError("discovered Exchange patch lost selection data")
        activity("REPLAY", f"Record terminal attempt outcome: {'succeeded' if succeeded else 'failed'}")
        mark_exchange_apply_finished(
            self.paths,
            self.artifact.identity,
            selection,
            (
                ExchangeApplyStatus.SUCCEEDED
                if succeeded
                else ExchangeApplyStatus.FAILED
            ),
            completed_commit=completed_commit,
            run_id=run_id,
        )


def _revalidate_exchange_discovery(
    paths: RegistrationUserPaths,
    expected_settings: dict[RepositoryId, tuple[RepositoryConfigurationPaths, RepositoryConfiguration]],
    expected_registry: RegistrySnapshot,
) -> None:
    with registry_lock(paths):
        current_registry = load_registry(paths)
        if current_registry != expected_registry:
            raise registry_error("repository registry changed during automatic patch discovery")
        for repo_id, (local, expected) in expected_settings.items():
            if configuration_paths_for_id(repo_id, current_registry) != local:
                raise repository_resolution_error("repository identity changed during discovery")
            current = revalidate_exchange_directory(load_configuration(local))
            if current != expected:
                raise configuration_error("repository configuration changed during automatic patch discovery")
            _require_exchange_configuration_allowed(
                current.exchange_directory, current_registry, exchange_must_exist=True,
            )


@dataclass(frozen=True, slots=True)
class ExchangeDiscoveryScope:
    """Repository and retry boundaries for one parameterless Apply."""

    repository_context: RepositoryContext | None
    allow_failed_retry: bool
    exchanges: tuple[ExchangeWatchTarget, ...] | None = None

    @property
    def is_repository_scoped(self) -> bool:
        """Whether candidates are restricted to one pre-resolved repository."""
        return self.repository_context is not None


def _manual_exchange_discovery_scope(
    current_directory: Path,
) -> ExchangeDiscoveryScope:
    """Resolve manual parameterless Apply to the current registered repository."""
    try:
        context = capture_repository_context(current_directory)
    except PatchHarborError as exc:
        if exc.error_kind is ErrorKind.REPOSITORY_RESOLUTION_ERROR:
            raise repository_resolution_error(
                "current directory is not inside a uniquely registered "
                "PatchHarbor repository"
            ) from exc
        raise
    return ExchangeDiscoveryScope(
        repository_context=context,
        allow_failed_retry=True,
    )


def _automatic_exchange_discovery_scope(
    exchanges: tuple[ExchangeWatchTarget, ...] | None = None,
) -> ExchangeDiscoveryScope:
    """Keep automatic Apply non-retrying, optionally limited to observed roots."""
    return ExchangeDiscoveryScope(
        repository_context=None,
        allow_failed_retry=False,
        exchanges=exchanges,
    )


def _watch_target(directory: Path, repository_ids: tuple[RepositoryId, ...]) -> ExchangeWatchTarget:
    """Observe directory identity without listing it or reading any bundles."""
    try:
        before = directory.stat(follow_symlinks=False)
        physical = directory.resolve(strict=True)
        after = directory.stat(follow_symlinks=False)
        if (physical != directory or not stat.S_ISDIR(before.st_mode)
                or not stat.S_ISDIR(after.st_mode) or not before.st_ino
                or (before.st_dev, before.st_ino) != (after.st_dev, after.st_ino)):
            raise configuration_error("exchange watch directory identity is unstable")
    except (OSError, RuntimeError) as exc:
        raise configuration_error(f"cannot observe exchange watch directory: {directory}") from exc
    return ExchangeWatchTarget(directory, before.st_dev, before.st_ino, repository_ids)


def _require_watch_target_unchanged(target: ExchangeWatchTarget) -> None:
    if _watch_target(target.directory, target.repository_ids) != target:
        raise configuration_error("exchange watch directory identity changed")


def _exchange_settings(
    registry: RegistrySnapshot, scope: ExchangeDiscoveryScope,
) -> tuple[
    dict[RepositoryId, tuple[RepositoryConfigurationPaths, RepositoryConfiguration]],
    dict[Path, ExchangeWatchTarget],
]:
    """Resolve and validate configuration before any Exchange scan/maintenance."""
    settings: dict[RepositoryId, tuple[RepositoryConfigurationPaths, RepositoryConfiguration]] = {}
    groups: dict[Path, list[RepositoryId]] = {}
    for mapping in registry.repositories:
        scoped = scope.repository_context
        if scoped is not None and mapping.repo_id != scoped.repo_id:
            continue
        if scoped is None and registered_repository_status(
            mapping.repository_path, mapping.repo_id,
        ) is RegistryStatus.MISSING:
            continue
        local = configuration_paths_for_id(mapping.repo_id, registry)
        configuration = load_configuration(local)
        if configuration.exchange_directory is None and scoped is None:
            continue
        revalidate_exchange_directory(configuration)
        _require_exchange_configuration_allowed(
            configuration.exchange_directory, registry, exchange_must_exist=True,
        )
        settings[mapping.repo_id] = local, configuration
        groups.setdefault(configuration.exchange_directory, []).append(mapping.repo_id)
    if scope.repository_context is not None and scope.repository_context.repo_id not in settings:
        raise repository_resolution_error("current repository is no longer registered")
    targets = {
        directory: _watch_target(directory, tuple(sorted(ids)))
        for directory, ids in sorted(groups.items(), key=lambda item: str(item[0]))
    }
    if scope.exchanges is not None:
        if scope.is_repository_scoped or scope.allow_failed_retry:
            raise configuration_error("watch scope is only valid for automatic Apply")
        # Explicit empty scope stays empty. Supplied snapshots are restrictions,
        # never trusted permissions; aliases/fabricated/stale observations fail.
        for target in scope.exchanges:
            if targets.get(target.directory) != target:
                raise configuration_error("exchange watch target is foreign or stale")
        allowed = {target.directory for target in scope.exchanges}
        targets = {path: target for path, target in targets.items() if path in allowed}
        settings = {repo_id: pair for repo_id, pair in settings.items()
                    if pair[1].exchange_directory in allowed}
    return settings, targets


def _watch_control_paths(paths: RegistrationUserPaths, registry: RegistrySnapshot) -> WatchControlPaths:
    # Advisory restoration paths only. A missing Exchange cannot be an approved
    # WatchTarget, but its nearest existing parent can reveal its return. Broken
    # settings still fail watch_targets()/Apply; they are never repaired here.
    exchanges = set()
    for mapping in registry.repositories:
        try:
            local = configuration_paths_for_id(mapping.repo_id, registry)
            settings = load_configuration(local, validate_directory=False)
        except PatchHarborError:
            continue
        if settings.exchange_directory is not None:
            exchanges.add(settings.exchange_directory)
    return WatchControlPaths(
        paths.registry_path,
        tuple(sorted({mapping.repository_path.value / ".patchharbor" / "config.json"
                      for mapping in registry.repositories}, key=str)),
        tuple(sorted(exchanges, key=str)),
    )


def watch_control_paths() -> WatchControlPaths:
    """Resolve control paths from registry even if local configuration is broken."""
    paths = registration_user_paths(create_configuration_directory=False)
    with registry_lock(paths):
        return _watch_control_paths(paths, load_registry(paths))


def watch_targets() -> WatchTargets:
    """Return validated physical roots, with no bundle discovery or state capture."""
    paths = registration_user_paths(create_configuration_directory=False)
    with registry_lock(paths):
        registry = load_registry(paths)
        _, targets = _exchange_settings(registry, _automatic_exchange_discovery_scope())
        controls = _watch_control_paths(paths, registry)
        return WatchTargets(tuple(targets.values()), controls.registry_path, controls.configuration_paths)


def apply_readiness(lock: ApplyLock) -> ApplyReadiness:
    """Probe only the named technical lock; no candidate work or reservation."""
    paths = registration_user_paths(create_configuration_directory=False)
    try:
        if lock.kind is ApplyLockKind.EXCHANGE_STATE:
            with _state_lock(paths):
                pass
        else:
            with registry_lock(paths):
                if lock.kind is ApplyLockKind.REPOSITORY:
                    registry = load_registry(paths)
                    if not any(mapping.repo_id == lock.repo_id for mapping in registry.repositories):
                        raise repository_resolution_error("lock repository is no longer registered")
                    with repository_lock(paths, lock.repo_id):
                        pass
    except LockBusyError as exc:
        return ApplyReadiness(blocked_on=exc.lock)
    return ApplyReadiness()


def _candidate_filename_key(artifact: ExchangeArtifact) -> tuple[str, str]:
    """Return one deterministic Unicode-normalized filename tie-break key."""
    filename = artifact.path.name
    return unicodedata.normalize("NFC", filename), filename


def _select_exchange_candidate(
    matches: list[ExchangeArtifact],
) -> ExchangeArtifact:
    """Select newest mtime_ns, then the lexicographically first filename."""
    return min(
        matches,
        key=lambda artifact: (
            -artifact.mtime_ns,
            *_candidate_filename_key(artifact),
            str(artifact.path),
        ),
    )


def _context_for_exchange_candidate(
    selection: ExchangePatchSelection,
    scope: ExchangeDiscoveryScope,
    contexts: dict[RepositoryId, RepositoryContext | None],
) -> RepositoryContext | None:
    """Resolve one candidate inside the requested repository scope."""
    scoped_context = scope.repository_context
    if scoped_context is not None:
        if selection.repo_id != scoped_context.repo_id:
            return None
        return scoped_context

    repo_id = selection.repo_id
    if repo_id not in contexts:
        contexts[repo_id] = capture_repository_context_for_id(repo_id)
    return contexts[repo_id]


def discover_exchange_patch(
    scope: ExchangeDiscoveryScope,
    *,
    archive: bool = True,
    output: OutputTargets | None = None,
) -> DiscoveredExchangePatch:
    """Return the newest eligible package inside one selection scope."""
    activity("DISCOVER", "Load Exchange configuration and repository registry", "heading")
    paths = configuration_user_paths()
    with registry_lock(paths):
        registry = load_registry(paths)
        settings, targets = _exchange_settings(registry, scope)

    found: list[ExchangeArtifact] = []
    # Shared physical paths are scanned once. Maintenance is still strictly per repo.
    for directory, target in targets.items():
        _require_watch_target_unchanged(target)
        try:
            artifacts = scan_exchange_directory(directory, paths=paths)
        except ExchangeScanError as exc:
            raise configuration_error(f"cannot scan exchange directory: {directory}") from exc
        _require_watch_target_unchanged(target)
        if archive:
            for repo_id in target.repository_ids:
                _require_watch_target_unchanged(target)
                local, configuration = settings[repo_id]
                artifacts = recover_exchange_artifacts(
                    artifacts, configuration=configuration, paths=paths, repository_id=repo_id,
                )
                maintenance = archive_exchange_artifacts(
                    artifacts, configuration=configuration, paths=paths, repository_id=repo_id,
                )
                artifacts = maintenance.remaining
                if output is not None:
                    output.write_warnings(maintenance.warnings)
        found.extend(artifacts)
    artifacts = tuple(found)

    matches: list[ExchangeArtifact] = []
    contexts: dict[RepositoryId, RepositoryContext | None] = {}
    if scope.repository_context is not None:
        contexts[scope.repository_context.repo_id] = scope.repository_context
    for artifact in artifacts:
        activity("SELECT", f"Evaluate candidate: {artifact.path.name}")
        if artifact.kind is not ExchangeArtifactKind.PATCH_PACKAGE:
            activity("SKIP", f"{artifact.path.name}: {artifact.kind.value}, not a patch", "detail")
            continue
        selection = artifact.selection
        if selection is None:
            raise RuntimeError("Patch Package artifact has no selection data")
        target_settings = settings.get(selection.repo_id)
        if target_settings is None or artifact.path.parent != target_settings[1].exchange_directory:
            activity("SKIP", f"{artifact.path.name}: not in its repository's configured Exchange", "detail")
            continue
        context = _context_for_exchange_candidate(selection, scope, contexts)
        if context is None:
            activity("SKIP", f"{artifact.path.name}: repository outside scope or unavailable", "detail")
            continue
        if not selection.matches_context(context):
            activity("SKIP", f"{artifact.path.name}: repository state does not match "
                     f"(expected base {str(selection.base_commit)}, "
                     f"state {str(selection.state_fingerprint)}; "
                     f"actual base {str(context.base_commit)}, "
                     f"state {str(context.state_fingerprint)})", "detail", identifiers=(str(selection.base_commit), str(selection.state_fingerprint), str(context.base_commit), str(context.state_fingerprint),))
            continue
        if artifact.apply_status is not None and not (
            scope.allow_failed_retry
            and artifact.apply_status is ExchangeApplyStatus.FAILED
        ):
            activity("SKIP", f"{artifact.path.name}: replay status {artifact.apply_status.value} blocks this origin", "detail")
            continue
        activity("MATCH", f"{artifact.path.name}: eligible, mtime_ns={artifact.mtime_ns}", "success")
        matches.append(artifact)

    _revalidate_exchange_discovery(paths, settings, registry)
    for target in targets.values():
        _require_watch_target_unchanged(target)

    if not matches:
        activity("SELECT", "No eligible patch remains after content, scope, state and replay checks", "warning")
        message = (
            "no state-bound patch package matches the current registered "
            "repository"
            if scope.is_repository_scoped
            else "no state-bound patch package matches a registered repository"
        )
        if not scope.is_repository_scoped:
            raise NoEligiblePatchError(
                message, FailureReason.PATCH_PACKAGE_ERROR, error_kind=ErrorKind.PATCH_PACKAGE_ERROR,
            )
        raise patch_package_error(message)

    artifact = _select_exchange_candidate(matches)
    activity("SELECT", f"Selected newest eligible patch: {artifact.path.name} "
             f"from {len(matches)} match(es); mtime_ns={artifact.mtime_ns}", "success")
    assert artifact.selection is not None
    local, configuration = settings[artifact.selection.repo_id]
    package = materialize_exchange_patch(
        artifact, directory=configuration.exchange_directory,
    )
    _revalidate_exchange_discovery(paths, settings, registry)
    target = targets[configuration.exchange_directory]
    _require_watch_target_unchanged(target)
    context = contexts.get(package.manifest.repo_id)
    if context is None or not _manifest_matches_context(package.manifest, context):
        raise patch_package_error(
            "selected exchange patch changed during automatic discovery"
        )
    return DiscoveredExchangePatch(
        artifact=artifact,
        package=package,
        paths=paths,
        configuration=configuration,
        configuration_paths=local,
        retry_failed=(artifact.apply_status is ExchangeApplyStatus.FAILED),
        watch_target=target,
    )


def _maintain_explicit_exchange(
    package: ValidatedPatchPackage, path: Path, *, output: OutputTargets | None,
) -> DiscoveredExchangePatch | None:
    """Optional maintenance for the manifest's repository, never for the CWD."""
    try:
        paths = configuration_user_paths()
        with registry_lock(paths):
            registry = load_registry(paths)
            local = configuration_paths_for_id(package.manifest.repo_id, registry)
            configuration = load_configuration(local)
            if configuration.exchange_directory is None:
                return None
            _require_exchange_configuration_allowed(
                configuration.exchange_directory, registry, exchange_must_exist=True,
            )
        selected = path.resolve(strict=True)
        artifacts = scan_exchange_directory(configuration.exchange_directory, paths=paths)
        artifacts = recover_exchange_artifacts(
            artifacts, configuration=configuration, paths=paths, repository_id=package.manifest.repo_id,
        )
        maintenance = archive_exchange_artifacts(
            artifacts, configuration=configuration, paths=paths,
            repository_id=package.manifest.repo_id, excluded_paths=frozenset({selected}),
        )
        if output is not None:
            output.write_warnings(maintenance.warnings)
        for artifact in maintenance.remaining:
            if artifact.path == selected and artifact.selection == ExchangePatchSelection.from_manifest(package.manifest):
                materialized = materialize_exchange_patch(artifact, directory=configuration.exchange_directory)
                if materialized != package:
                    return None
                return DiscoveredExchangePatch(
                    artifact, package, paths, configuration, local, explicitly_selected=True,
                )
    except (PatchHarborError, ExchangeScanError, OSError, ValueError):
        # Mandatory config validation happens in the target preflight; never bypass it.
        pass
    return None


def _maintain_bundle_exchange(path: Path) -> None:
    """Maintain only the selected repository before creating its Result Bundle."""
    try:
        paths = configuration_user_paths()
        with registry_lock(paths):
            registry = load_registry(paths)
            local = configuration_paths_for_repository(path, registry)
            configuration = load_configuration(local)
            if configuration.exchange_directory is None:
                return
            _require_exchange_configuration_allowed(
                configuration.exchange_directory, registry, exchange_must_exist=True,
            )
        artifacts = scan_exchange_directory(configuration.exchange_directory, paths=paths)
        artifacts = recover_exchange_artifacts(
            artifacts, configuration=configuration, paths=paths, repository_id=local.repo_id,
        )
        archive_exchange_artifacts(
            artifacts, configuration=configuration, paths=paths, repository_id=local.repo_id,
        )
    except (PatchHarborError, ExchangeScanError, OSError, ValueError):
        pass


def _complete_apply_result_bundle(
    resolved: SafeResolvedRepository,
    package: ValidatedPatchPackage,
    *,
    session: RunSession,
    resources: PinnedResultResources,
    dry_run: bool,
    warnings: tuple[str, ...],
    primary_outcome: ApplyPrimaryOutcome,
    execution_log: bytes | None = None,
    actual_context: RepositoryContext | None = None,
    before_result_publication: Callable[[str], None] | None = None,
) -> RunReport:
    activity("BUNDLE", "Capture and publish the current Apply Result Bundle", "heading")
    return create_apply_result_bundle(
        resolved.repository,
        resolved.repo_id,
        resolved.registry_snapshot,
        actual_context if actual_context is not None else resolved.context,
        package.manifest,
        target=resolved.result_target,
        publication=resolved.result_publication,
        warnings=warnings,
        session=session,
        resources=resources,
        dry_run=dry_run,
        primary_outcome=primary_outcome,
        execution_log=execution_log,
        package_sha256=package.package_sha256,
        before_publish=before_result_publication,
    )


def _complete_mutation_result_bundle(
    mutation_gate: ApplyMutationGate,
    *,
    primary_outcome: ApplyPrimaryOutcome,
    execution_log: bytes | None = None,
    actual_context: RepositoryContext | None = None,
    before_result_publication: Callable[[str], None] | None = None,
) -> RunReport:
    """Complete one apply result from the single checked mutation gate."""
    return _complete_apply_result_bundle(
        mutation_gate.resolved,
        mutation_gate.package,
        session=mutation_gate.session,
        resources=mutation_gate.result_resources,
        dry_run=mutation_gate.dry_run,
        warnings=mutation_gate.warnings,
        primary_outcome=primary_outcome,
        execution_log=execution_log,
        actual_context=actual_context,
        before_result_publication=before_result_publication,
    )


@contextmanager
def preflight_patch_package_repository(
    package: ValidatedPatchPackage,
    *,
    output_directory: Path | None = None,
    session: RunSession | None = None,
    dry_run: bool = True,
    output: OutputTargets | None = None,
    before_mutation: Callable[[], None] | None = None,
) -> Iterator[ApplyMutationGate]:
    """Yield the explicit mutation gate while private inputs and locks live."""
    actual_session = session or RunSession.start()
    manifest = package.manifest
    with ExitStack() as repository_scope:
        try:
            resolved = repository_scope.enter_context(
                safely_resolved_repository(
                    manifest,
                    session=actual_session,
                    output_directory=output_directory,
                )
            )
        except PatchHarborError as error:
            report = unresolved_apply_report(
                session=actual_session,
                dry_run=dry_run,
                warnings=package.warnings,
                error=error,
            )
            raise report.reported_error() from error

        # Pin the running producer before payload writes, entrypoint execution,
        # or observer callbacks can change the installation/source checkout.
        resources = capture_result_resources()
        emit(RepositoryResolved(resolved.context))

        activity("BINDING", f"Compare full manifest binding: base {str(manifest.base_commit)}, "
                 f"state {str(manifest.state_fingerprint)}", identifiers=(str(manifest.base_commit), str(manifest.state_fingerprint),))
        if not resolved.matches_manifest_state(manifest):
            activity("BINDING", "Manifest and repository state differ; mutation refused", "error")
            error = state_mismatch_error(
                "patch package does not match the resolved repository state"
            )
            report = _complete_apply_result_bundle(
                resolved,
                package,
                session=actual_session,
                resources=resources,
                dry_run=dry_run,
                warnings=package.warnings,
                primary_outcome=ApplyPrimaryOutcome.from_tool_error(error),
            )
            raise report.reported_error()

        activity("BINDING", "Repository binding matches", "success")
        with ExitStack() as private_resources:
            try:
                prepared_package = private_resources.enter_context(
                    prepare_patch_package(
                        package,
                        repository=resolved.repository.value,
                    )
                )
                validate_bundle_payload_targets(
                    prepared_package.payloads,
                    cwd=resolved.repository.value,
                )
            except PatchHarborError as error:
                report = _complete_apply_result_bundle(
                    resolved,
                    package,
                    session=actual_session,
                    resources=resources,
                    dry_run=dry_run,
                    warnings=package.warnings,
                    primary_outcome=ApplyPrimaryOutcome.from_tool_error(error),
                )
                raise report.reported_error() from error

            if output is not None:
                output.write_warnings(prepared_package.warnings)

            emit(ScriptPrepared(
                name=package.entrypoint.relative_path,
                index=1, total=1,
                messages=tuple(
                    (message.name, message.text)
                    for message in prepared_package.entrypoint.script.messages
                ),
                warnings=prepared_package.warnings,
            ))

            yield ApplyMutationGate(
                session=actual_session,
                resolved=resolved,
                package=package,
                prepared_package=prepared_package,
                dry_run=dry_run,
                result_resources=resources,
                before_mutation=before_mutation,
            )


def dry_run_patch_package(
    package: ValidatedPatchPackage,
    *,
    output_directory: Path | None = None,
    output: OutputTargets | None = None,
    session: RunSession | None = None,
) -> RunReport:
    """Complete one safe dry-run and publish its unchanged Result Bundle."""
    actual_session = session or RunSession.start()
    with preflight_patch_package_repository(
        package,
        output_directory=output_directory,
        session=actual_session,
        dry_run=True,
        output=output,
    ) as mutation_gate:
        activity("DRY-RUN", "Validation complete; no payload write or entrypoint execution", "success")
        report = _complete_mutation_result_bundle(
            mutation_gate,
            primary_outcome=ApplyPrimaryOutcome.dry_run_success(),
        )
        if report.completion_tool_error is not None:
            raise report.reported_error()
        return report


def _publish_attempt_outcome(
    mutation_gate: ApplyMutationGate,
    publisher: Callable[[bool, GitObjectId | None], None] | None,
    *,
    succeeded: bool,
    execution_log: bytes | None = None,
    actual_context: RepositoryContext | None = None,
    completed_report: RunReport | None = None,
) -> None:
    """Persist one automatic outcome or complete it as a PatchHarbor failure."""
    if publisher is None:
        return
    try:
        completed_commit = None
        if succeeded:
            # This optional receipt must never turn execution success into a
            # claim that a commit exists when state/history capture is unclear.
            try:
                resolved = mutation_gate.resolved
                after = repository_context_from_snapshot(
                    resolved.repository, resolved.repo_id,
                    capture_consistent_repository_snapshot(resolved.repository),
                )
                completed_commit = completed_commit_for_context(resolved.context, after)
            except (PatchHarborError, OSError, ValueError):
                pass
        publisher(succeeded, completed_commit)
    except PatchHarborError as error:
        if completed_report is not None:
            # The successful execution bundle is already published and pinned.
            # Do not overwrite it or attempt another bundle with the same name.
            report = RunReport.completed_apply(
                timing=completed_report.timing, dry_run=completed_report.dry_run,
                context=completed_report.context, repository=completed_report.repository,
                repo_id=completed_report.repo_id, warnings=completed_report.warnings,
                primary_outcome=ApplyPrimaryOutcome.from_tool_error(error),
                result_bundle=completed_report.result_bundle,
            )
        else:
            report = _complete_mutation_result_bundle(
                mutation_gate,
                primary_outcome=ApplyPrimaryOutcome.from_tool_error(error),
                execution_log=execution_log,
                actual_context=actual_context,
            )
        raise report.reported_error() from error


def _require_payload_mutation(
    mutation_gate: ApplyMutationGate,
    *,
    publish_attempt_outcome: Callable[[bool, GitObjectId | None], None] | None = None,
) -> None:
    """Complete a failed mutation as the primary apply result."""
    try:
        result = apply_payload_mutation(mutation_gate)
    except PatchHarborError as error:
        report = _complete_mutation_result_bundle(
            mutation_gate,
            primary_outcome=ApplyPrimaryOutcome.from_tool_error(error),
        )
        raise report.reported_error() from error

    if result.success:
        return
    if result.failure_kind is not MutationFailureKind.STATE_MISMATCH:
        _publish_attempt_outcome(
            mutation_gate,
            publish_attempt_outcome,
            succeeded=False,
            actual_context=result.context,
        )
    error = result.error
    if error is None:
        raise RuntimeError("failed mutation result has no error")
    report = _complete_mutation_result_bundle(
        mutation_gate,
        primary_outcome=ApplyPrimaryOutcome.from_tool_error(error),
        actual_context=result.context,
    )
    raise report.reported_error()


def _complete_entrypoint_execution(
    mutation_gate: ApplyMutationGate,
    execution: ScriptExecutionResult,
    *,
    publish_attempt_outcome: Callable[[bool, GitObjectId | None], None] | None = None,
    before_result_publication: Callable[[str], None] | None = None,
) -> RunReport:
    """Publish one execution result before unwinding the shared apply scope."""
    primary_outcome = ApplyPrimaryOutcome.from_execution_result(
        entrypoint_started=execution.entrypoint_started,
        entrypoint_exit_code=execution.entrypoint_exit_code,
        patchharbor_error=execution.patchharbor_error,
    )
    report = _complete_mutation_result_bundle(
        mutation_gate,
        primary_outcome=primary_outcome,
        execution_log=(execution.output if execution.entrypoint_started else None),
        before_result_publication=before_result_publication,
    )
    _publish_attempt_outcome(
        mutation_gate,
        publish_attempt_outcome,
        succeeded=primary_outcome.result.success,
        execution_log=(execution.output if execution.entrypoint_started else None),
        completed_report=report,
    )

    if execution.patchharbor_error is not None:
        raise report.reported_error()
    if primary_outcome.result.success and report.completion_tool_error is not None:
        raise report.reported_error()
    return report


def apply_patch_package(
    package: ValidatedPatchPackage,
    *,
    output_directory: Path | None = None,
    timeout_seconds: float = DEFAULT_TIMEOUT_SECONDS,
    output: OutputTargets | None = None,
    session: RunSession | None = None,
    before_mutation: Callable[[], None] | None = None,
    publish_attempt_outcome: Callable[[bool, GitObjectId | None], None] | None = None,
    before_result_publication: Callable[[str], None] | None = None,
) -> RunReport:
    """Write one validated package, run its private entrypoint, and bundle it."""
    actual_session = session or RunSession.start()
    with preflight_patch_package_repository(
        package,
        output_directory=output_directory,
        session=actual_session,
        dry_run=False,
        output=output,
        before_mutation=before_mutation,
    ) as mutation_gate:
        _require_payload_mutation(
            mutation_gate,
            publish_attempt_outcome=publish_attempt_outcome,
        )
        prepared_package = mutation_gate.prepared_package
        execution = execute_prepared_script_with_log(
            prepared_package.entrypoint.path,
            interpreter=prepared_package.entrypoint.interpreter,
            cwd=mutation_gate.resolved.repository.value,
            timeout_seconds=timeout_seconds,
            execution_log_path=prepared_package.execution_log_path,
            output=output,
        )
        return _complete_entrypoint_execution(
            mutation_gate,
            execution,
            publish_attempt_outcome=publish_attempt_outcome,
            before_result_publication=before_result_publication,
        )


def run_apply_path(
    path: Path | None,
    *,
    dry_run: bool,
    output_directory: Path | None = None,
    timeout_seconds: float = DEFAULT_TIMEOUT_SECONDS,
    output: OutputTargets | None = None,
    session: RunSession | None = None,
    automatic: bool = False,
    current_directory: Path | None = None,
    exchanges: tuple[ExchangeWatchTarget, ...] | None = None,
) -> RunReport:
    """Run one Apply request through a single public application boundary."""
    actual_session = session or RunSession.start()
    if exchanges is not None and (not automatic or path is not None):
        raise ValueError("Exchange watch scope requires automatic parameterless Apply")
    attempted = False

    def finish(report: RunReport, error: PatchHarborError | None = None) -> RunReport:
        if not automatic:
            return report
        status = AutomaticApplyStatus.ERROR
        blocked_on = None
        if attempted:
            status = AutomaticApplyStatus.ATTEMPTED
        elif isinstance(error, NoEligiblePatchError):
            status = AutomaticApplyStatus.NO_CANDIDATE
        elif dry_run and report.success:
            status = AutomaticApplyStatus.DRY_RUN
        else:
            # Completion may wrap a pre-mutation lock failure to attach its
            # Result Bundle. Follow explicit causes, never diagnostic text.
            cause: BaseException | None = error
            seen: set[int] = set()
            while cause is not None and id(cause) not in seen:
                seen.add(id(cause))
                if isinstance(cause, LockBusyError):
                    status, blocked_on = AutomaticApplyStatus.LOCKED, cause.lock
                    break
                cause = cause.__cause__
        return replace(report, automatic=AutomaticApplyResult(status, blocked_on))

    def publish_attempt() -> None:
        nonlocal attempted
        assert discovered is not None
        discovered.publish_attempt(str(actual_session.run_id))
        attempted = True

    try:
        discovered: DiscoveredExchangePatch | None = None
        if path is None:
            scope = (
                _automatic_exchange_discovery_scope(exchanges)
                if automatic
                else _manual_exchange_discovery_scope(
                    Path.cwd() if current_directory is None else current_directory
                )
            )
            discovered = discover_exchange_patch(scope, archive=not dry_run, output=output)
            selected_path = discovered.artifact.path
            package = discovered.package
        else:
            selected_path = path
            package = resolve_patch_package(selected_path)
            if not dry_run:
                discovered = _maintain_explicit_exchange(package, selected_path, output=output)
    except PatchHarborError as error:
        return finish(unresolved_apply_report(
            session=actual_session,
            dry_run=dry_run,
            error=error,
        ), error)

    emit(RequestStarted(
        source_name=str(selected_path),
        requested_repo_id=str(package.manifest.repo_id),
        files=(
            PackageFile(package.entrypoint.relative_path,
                        len(package.entrypoint.content), "entrypoint"),
            *(PackageFile(payload.relative_path, len(payload.content), "payload")
              for payload in package.payloads),
        ),
        script_total=1,
        warnings=package.warnings,
    ))
    if output is not None:
        output.write_warnings(package.warnings)

    try:
        if dry_run:
            return finish(dry_run_patch_package(
                package,
                output_directory=output_directory,
                output=output,
                session=actual_session,
            ))
        return finish(apply_patch_package(
            package,
            output_directory=output_directory,
            timeout_seconds=timeout_seconds,
            output=output,
            session=actual_session,
            before_mutation=(
                publish_attempt
                if discovered is not None
                else None
            ),
            before_result_publication=(
                (lambda digest: discovered.publish_result_digest(str(actual_session.run_id), digest))
                if discovered is not None else None
            ),
            publish_attempt_outcome=(
                (lambda succeeded, commit: discovered.publish_outcome(
                    succeeded, commit, run_id=str(actual_session.run_id),
                ))
                if discovered is not None
                else None
            ),
        ))
    except PatchHarborError as error:
        report = error.run_report
        if isinstance(report, RunReport):
            return finish(report, error)
        return finish(unresolved_apply_report(
            session=actual_session,
            dry_run=dry_run,
            warnings=package.warnings,
            error=error,
        ), error)


def register_repository(
    path: Path,
    *,
    new_id: bool = False,
) -> RepositoryContext:
    """Register one local Git repository and return its current context."""
    repository = require_clean_repository(path)
    _repo_id, repository_path = register_local_repository(
        repository.value,
        new_id=new_id,
    )
    return capture_repository_context(repository_path.value)


def repository_context(path: Path) -> RepositoryContext:
    """Return the current reproducible context of one registered repository."""
    context = capture_repository_context(path)
    load_configuration(RepositoryConfigurationPaths(context.repository_path, context.repo_id), validate_directory=False)
    return context


def bundle_repository(
    path: Path,
    *,
    output_directory: Path | None = None,
) -> ManualResultBundle:
    """Create one manual Result Bundle for a registered repository."""
    _maintain_bundle_exchange(path)
    return create_manual_result_bundle(
        path,
        output_directory=output_directory,
    )


def registered_repositories() -> RegistryListResult:
    """Return one structured view of all registered local instances."""
    return list_registered_repositories()


def unregister_repository(
    selector: str,
    *,
    cwd: Path,
) -> tuple[RepositoryId, RepositoryPath]:
    """Remove one central repository mapping."""
    return unregister_local_repository(selector, cwd=cwd)


def _execute_bundle_script(
    bundle_script: BundleScript,
    *,
    script_index: int,
    script_total: int,
    cwd: Path,
    timeout_seconds: float,
    output: OutputTargets | None = None,
) -> int:
    parsed_script = parse_script(bundle_script.text)
    script_warnings = parsed_script.warnings
    emit(ScriptPrepared(
        name=bundle_script.display_name,
        index=script_index, total=script_total,
        messages=tuple((message.name, message.text) for message in parsed_script.messages),
        warnings=script_warnings,
    ))
    if output is not None:
        output.write_warnings(script_warnings)
    return execute_script_text(
        parsed_script.text,
        cwd=cwd,
        timeout_seconds=timeout_seconds,
        output=output,
    )


def run_input_artifact(
    artifact: InputArtifact,
    *,
    cwd: Path,
    timeout_seconds: float,
    output: OutputTargets | None = None,
    resource_policy: ResourcePolicy = DEFAULT_RESOURCE_POLICY,
) -> int:
    """Resolve and execute every script in one input artifact."""
    bundle = resolve_patch_bundle(artifact, policy=resource_policy)
    emit(RequestStarted(
        source_name=artifact.display_name,
        files=tuple(PackageFile(payload.relative_path, len(payload.content), "bundle")
                    for payload in bundle.payloads),
        script_total=len(bundle.scripts), warnings=bundle.warnings,
    ))
    if output is not None:
        output.write_warnings(bundle.warnings)
    write_bundle_payloads(bundle.payloads, cwd=cwd)
    last_exit_code = 0
    script_total = len(bundle.scripts)
    for script_index, bundle_script in enumerate(bundle.scripts, start=1):
        last_exit_code = _execute_bundle_script(
            bundle_script,
            script_index=script_index,
            script_total=script_total,
            cwd=cwd,
            timeout_seconds=timeout_seconds,
            output=output,
        )
        if last_exit_code != 0:
            return last_exit_code
    return last_exit_code


def run_standard_input(
    stream: TextIO,
    *,
    cwd: Path,
    timeout_seconds: float,
    output: OutputTargets | None = None,
    resource_policy: ResourcePolicy = DEFAULT_RESOURCE_POLICY,
) -> int:
    """Own the temporary stdin artifact for exactly one runner request."""
    with stdin_input_artifact(stream, policy=resource_policy) as artifact:
        return run_input_artifact(
            artifact,
            cwd=cwd,
            timeout_seconds=timeout_seconds,
            output=output,
            resource_policy=resource_policy,
        )


def _is_directory_candidate(
    path: Path,
    resource_policy: ResourcePolicy,
) -> bool:
    try:
        resolve_patch_bundle(
            file_input_artifact(path),
            policy=resource_policy,
        )
        activity("SELECT", f"Manual input candidate is executable: {path.name}", "success")
        return True
    except PatchHarborError as exc:
        activity("SKIP", f"{path.name}: not a valid manual input ({exc})", "detail")
        return False


def discover_directory_candidates(
    directory: Path,
    *,
    resource_policy: ResourcePolicy = DEFAULT_RESOURCE_POLICY,
) -> tuple[DirectoryCandidate, ...]:
    """Return sorted regular files that resolve to a PatchBundle."""
    return tuple(
        candidate
        for candidate in list_directory_entries(directory)
        if _is_directory_candidate(candidate.path, resource_policy)
    )


def _run_selected_candidate(
    candidate: DirectoryCandidate,
    *,
    cwd: Path,
    timeout_seconds: float,
    output: OutputTargets | None = None,
    resource_policy: ResourcePolicy = DEFAULT_RESOURCE_POLICY,
) -> int:
    if candidate.path.is_symlink() or not candidate.path.is_file():
        raise PatchHarborError(
            f"selected script is no longer available: {candidate.display_name}",
            FailureReason.SOURCE_ERROR,
        )

    return run_input_artifact(
        file_input_artifact(candidate.path),
        cwd=cwd,
        timeout_seconds=timeout_seconds,
        output=output,
        resource_policy=resource_policy,
    )


def run_script_path(
    path: Path,
    *,
    cwd: Path,
    timeout_seconds: float,
    select_candidate: Callable[[tuple[DirectoryCandidate, ...]], DirectoryCandidate] | None = None,
    output: OutputTargets | None = None,
    resource_policy: ResourcePolicy = DEFAULT_RESOURCE_POLICY,
) -> int:
    """Run a script/ZIP file or select one from a directory."""
    if not path.is_dir():
        return run_input_artifact(
            file_input_artifact(path),
            cwd=cwd,
            timeout_seconds=timeout_seconds,
            output=output,
            resource_policy=resource_policy,
        )

    candidates = discover_directory_candidates(
        path,
        resource_policy=resource_policy,
    )
    if not candidates:
        raise PatchHarborError(
            f"no PatchHarbor scripts found in directory {path}",
            FailureReason.NO_VALID_SCRIPT,
        )
    if len(candidates) == 1:
        selected = candidates[0]
    elif select_candidate is None:
        raise PatchHarborError(
            "multiple scripts found; an explicit candidate selector is required",
            FailureReason.USAGE_ERROR,
        )
    else:
        selected = select_candidate(candidates)
        if selected not in candidates:
            raise PatchHarborError("selector returned an unknown candidate", FailureReason.USAGE_ERROR)
    activity("SELECT", f"Selected manual candidate: {selected.display_name}", "success")
    return _run_selected_candidate(
        selected,
        cwd=cwd,
        timeout_seconds=timeout_seconds,
        output=output,
        resource_policy=resource_policy,
    )
