"""Read complete format-1/2 Result facts without imposing archival success policy."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
import hashlib
import math
import os
from pathlib import Path, PurePosixPath, PureWindowsPath
from uuid import UUID

from patchharbor.bundle_handoff import (
    BundleHandoff, CHAT_INSTRUCTIONS_NAME, ENVIRONMENT_NAME, ENVIRONMENT_MARKER,
    MAX_HANDOFF_ENTRY_BYTES,
)
from patchharbor.bundle_names import validate_bundle_suffix
from patchharbor.bundle_paths import BundlePathError, normalize_bundle_path
from patchharbor.errors import ErrorKind, FailureReason, PatchHarborError
from patchharbor.exchange_state import ExchangePatchSelection
from patchharbor.exit_status import reason_for_exit_code
from patchharbor.json_document import parse_json_document as _document
from patchharbor.result_runtime import ResultRuntime, read_result_runtime
from patchharbor.models import BundlePayload, GitObjectFormat, GitObjectId, RepositoryId
from patchharbor.platform.filesystem import (
    FileChangedDuringRead, FileSystemOperationError, UnsupportedFileTypeError,
    read_stable_regular_file_with_sha256,
)
from patchharbor.progress import activity
from patchharbor.repository_paths import RepositoryRelativePath, validate_repository_paths
from patchharbor.resource_policy import DEFAULT_RESOURCE_POLICY, ResourcePolicy
from patchharbor.run_report import PrimaryResult, PrimaryResultKind
from patchharbor.state_fingerprint import state_fingerprint_digest
from patchharbor.zip_payloads import InvalidZipArchiveError, NotZipArchiveError, ZipPayloadError, read_zip_payload_bytes


CLEAN_FINGERPRINT = state_fingerprint_digest(
    staged_records=(), unstaged_records=(), untracked_records=(),
)[:16]
_RESULT_MARKER = "patch-harbor-result-bundle"
_BINDING_FIELDS = {"repo_id", "base_commit", "state_fingerprint", "fingerprint_algorithm"}
_MANIFEST_FIELDS = _BINDING_FIELDS | {
    "marker", "format_version", "created_at", "run_id", "dirty", "dry_run",
    "entrypoint_started", "execution_present", "primary_result",
    "result_bundle_status", "base_entries", "untracked_entries",
}
_APPLY_FIELDS = {
    prefix + name for prefix in ("expected_", "actual_")
    for name in ("base_commit", "state_fingerprint", "fingerprint_algorithm")
}
_RECEIPT_FIELDS = {"patch_sha256", "completed_commit"}
_RUN_FIELDS = _BINDING_FIELDS | {
    "run_id", "operation", "dry_run", "started_at", "ended_at", "duration_seconds",
    "repository_resolved", "repository_path", "warnings", "execution_present",
    "primary_result", "result_bundle", "process_exit_code",
}


def _selection(document: dict[str, object]) -> ExchangePatchSelection:
    if any(type(document.get(key)) is not str for key in _BINDING_FIELDS):
        raise ValueError("incomplete bundle binding")
    base = document["base_commit"]
    return ExchangePatchSelection(
        repo_id=RepositoryId(document["repo_id"]),
        base_commit=GitObjectId(base, GitObjectFormat.for_hex_length(len(base))),
        state_fingerprint=document["state_fingerprint"],
        fingerprint_algorithm=document["fingerprint_algorithm"],
    )


def _timestamp(value: object) -> datetime:
    if type(value) is not str:
        raise ValueError("invalid bundle timestamp")
    stamp = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if stamp.tzinfo is None:
        raise ValueError("bundle timestamp has no timezone")
    return stamp


@dataclass(frozen=True, slots=True)
class ReferenceContext:
    """Recorded context; the foreign repository path is text, never resolved locally."""

    repo_id: RepositoryId
    repository_path: str
    base_commit: GitObjectId
    dirty: bool
    state_fingerprint: str
    fingerprint_algorithm: str


@dataclass(frozen=True, slots=True)
class ResultFacts:
    context: ReferenceContext
    run_id: str
    operation: str
    dry_run: bool
    primary_result: PrimaryResult
    warnings: tuple[str, ...]
    base_entries: tuple[tuple[str, str, str], ...]
    expected: ExchangePatchSelection | None
    patch_sha256: str | None
    completed_commit: GitObjectId | None
    format_version: int = 1
    runtime: ResultRuntime | None = None
    handoff_present: bool = False


@dataclass(frozen=True, slots=True)
class CapturedResultReference:
    """Internal request-local facts from one completely validated byte capture.

    The small handoff pair retains its exact immutable bytes, not mutable JSON
    objects or the full archive. Decode those bytes when rendering new metadata;
    never reopen the reference path for its suffix or target environment. This
    value is not an authenticity token and must come from capture_result_reference.
    """

    facts: ResultFacts
    sha256: str
    bundle_suffix: str
    handoff: BundleHandoff | None


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def _primary(document: object) -> PrimaryResult:
    fields = {"kind", "success", "patchharbor_error_code", "entrypoint_started",
              "entrypoint_exit_code", "timed_out", "interrupted"}
    _require(type(document) is dict and set(document) == fields, "invalid primary result schema")
    kind = PrimaryResultKind(document["kind"])
    code = document["patchharbor_error_code"]
    reason = None if code is None else reason_for_exit_code(code)
    primary = PrimaryResult(kind, document["success"], reason,
                            document["entrypoint_started"], document["entrypoint_exit_code"],
                            document["timed_out"], document["interrupted"])
    _require(primary.success == (kind in (PrimaryResultKind.SUCCESS, PrimaryResultKind.DRY_RUN_SUCCESS)),
             "inconsistent primary success kind")
    if reason is not None:
        # Run documents retain the numeric reason and primary kind, not the
        # original ErrorKind. Accept its categorized and legacy generic forms.
        category = {
            FailureReason.STATE_MISMATCH: ErrorKind.STATE_MISMATCH,
            FailureReason.REPOSITORY_BUSY: ErrorKind.REPOSITORY_BUSY,
            FailureReason.REPOSITORY_ERROR: ErrorKind.REPOSITORY_RESOLUTION_ERROR,
            FailureReason.UNSUPPORTED_REPOSITORY_STATE: ErrorKind.UNSUPPORTED_REPOSITORY_STATE,
        }.get(reason, ErrorKind.TOOL_ERROR)
        possible = {PrimaryResultKind.for_tool_error(PatchHarborError("reference", reason, error_kind=c))
                    for c in (ErrorKind.TOOL_ERROR, category)}
        _require(kind in possible,
                 "inconsistent primary error kind")
    return primary


def _hex_digest(value: object) -> bool:
    return type(value) is str and len(value) == 64 and all(c in "0123456789abcdef" for c in value)


def result_member_path(raw_path: str, *, is_directory: bool = False) -> str:
    """Snapshot paths follow repository rules; patch package paths remain unchanged."""
    prefix, separator, relative = raw_path.partition("/")
    if prefix not in ("base", "untracked") or not separator or not relative:
        return normalize_bundle_path(raw_path, is_directory=is_directory)
    if is_directory:
        _require(relative.endswith("/"), "invalid Result directory name")
        relative = relative[:-1]
    try:
        RepositoryRelativePath(relative.encode("utf-8"))
    except (PatchHarborError, UnicodeError) as exc:
        raise BundlePathError("invalid Result snapshot path") from exc
    return prefix + "/" + relative


def _handoff(files: dict[str, bytes], context: dict, run: dict) -> set[str]:
    names = {"environment.json", CHAT_INSTRUCTIONS_NAME}
    if not names.intersection(files):
        return set()
    for name in names:
        raw = files[name]
        _require(bool(raw) and len(raw) <= MAX_HANDOFF_ENTRY_BYTES and not raw.startswith(b"\xef\xbb\xbf"),
                 "invalid result handoff")
        raw.decode("utf-8")
    environment = _document(files["environment.json"])
    _require(environment.get("marker") == ENVIRONMENT_MARKER
             and type(environment.get("format_version")) is int and environment["format_version"] == 1
             and environment.get("bundle_type") == "Result"
             and environment.get("repository_context") == {k: context[k] for k in _BINDING_FIELDS}
             and environment.get("run_id") == run["run_id"]
             and environment.get("bundle_suffix") == context.get("bundle_suffix", ""),
             "inconsistent result handoff")
    if "repository_path" in environment:
        _require(environment["repository_path"] == run["repository_path"], "inconsistent handoff path")
    if "captured_at" in environment:
        _timestamp(environment["captured_at"])
    # Supplementary metadata is never used as a local path or execution input.
    pending = [environment]
    while pending:
        value = pending.pop()
        if type(value) is dict:
            pending.extend(value.values())
        elif type(value) is list:
            pending.extend(value)
        elif type(value) is float:
            _require(math.isfinite(value), "non-finite handoff value")
    return names


def has_result_marker(payloads: tuple[BundlePayload, ...]) -> bool:
    """One strict marker hint for classification, never a validity claim."""
    manifest = next((p.content for p in payloads if p.relative_path == "manifest.json"), None)
    try:
        return manifest is not None and _document(manifest).get("marker") == _RESULT_MARKER
    except (ValueError, RecursionError):
        return False


def read_result_or_patch_payloads(content: bytes, *,
                                  policy: ResourcePolicy = DEFAULT_RESOURCE_POLICY) -> tuple[BundlePayload, ...]:
    """Keep the patch profile strict; allow snapshot paths only for Result hints.

    Member type/path validation fails before any content read. Only that failure
    permits retrying with the repository namespace, never a CRC or budget error.
    A marked Result still requires complete validation before it is evidence.
    """
    try:
        return read_zip_payload_bytes(content, policy=policy)
    except InvalidZipArchiveError as original:
        payloads = read_zip_payload_bytes(content, policy=policy, path_normalizer=result_member_path)
        if not has_result_marker(payloads):
            raise original
        return payloads


def parse_result_payloads(payloads: tuple[BundlePayload, ...], *,
                          resource_policy: ResourcePolicy = DEFAULT_RESOURCE_POLICY) -> ResultFacts:
    """Validate ZIP-reader output; neither apply deltas nor infer a live fingerprint."""
    return _parse_result_payloads(payloads, resource_policy=resource_policy, verify_runtime=True)


def _parse_repository_payloads(payloads: tuple[BundlePayload, ...], *,
                               resource_policy: ResourcePolicy = DEFAULT_RESOURCE_POLICY) -> ResultFacts:
    """Private handoff fallback: repository evidence only, never full Result validity.

    Outer ZIP/path/CRC limits still apply before this boundary. The original
    artifact is neither rewritten nor downgraded. Native readers and archive/
    recovery callers always use parse_result_payloads with runtime verification.
    """
    return _parse_result_payloads(payloads, resource_policy=resource_policy, verify_runtime=False)


def _parse_result_payloads(payloads: tuple[BundlePayload, ...], *,
                           resource_policy: ResourcePolicy, verify_runtime: bool) -> ResultFacts:
    files = {entry.relative_path: entry.content for entry in payloads}
    modes = {entry.relative_path: entry.unix_mode for entry in payloads}
    _require(len(files) == len(payloads), "duplicate result members")
    _require(len(payloads) <= resource_policy.max_zip_entries
             and all(len(raw) <= resource_policy.max_content_bytes for raw in files.values())
             and sum(len(raw) for raw in files.values()) <= resource_policy.max_zip_total_bytes,
             "Result payload budget exceeded")
    manifest = _document(files["manifest.json"])
    context = _document(files["context.json"])
    run = _document(files["logs/run.json"])
    version = manifest.get("format_version")
    manifest_fields = _MANIFEST_FIELDS | ({"runtime"} if version == 2 else set())
    _require(manifest.get("marker") == _RESULT_MARKER
             and type(version) is int and version in (1, 2)
             and set(manifest) in (manifest_fields, manifest_fields | _APPLY_FIELDS,
                                   manifest_fields | _APPLY_FIELDS | _RECEIPT_FIELDS)
             and set(context) in (_BINDING_FIELDS | {"dirty", "created_at"},
                                  _BINDING_FIELDS | {"dirty", "created_at", "bundle_suffix"})
             and set(run) == _RUN_FIELDS, "unsupported or incomplete result schema")
    binding = _selection(manifest)
    _require(_selection(context) == binding == _selection(run), "inconsistent result binding")
    for doc, fields in ((manifest, ("dirty", "dry_run", "entrypoint_started", "execution_present")),
                        (context, ("dirty",)), (run, ("dry_run", "repository_resolved", "execution_present"))):
        _require(all(type(doc[key]) is bool for key in fields), "invalid result boolean")
    _require(context["dirty"] == manifest["dirty"] and run["dry_run"] == manifest["dry_run"]
             and run["repository_resolved"] and manifest["result_bundle_status"] == "created",
             "inconsistent result status")
    validate_bundle_suffix(context.get("bundle_suffix", ""))
    _require(type(manifest["run_id"]) is str, "invalid run ID")
    identity = UUID(manifest["run_id"])
    _require(identity.version == 4 and str(identity) == manifest["run_id"] == run["run_id"], "invalid run ID")
    _require(context["created_at"] == manifest["created_at"] == run["started_at"], "inconsistent run time")
    _require(_timestamp(run["ended_at"]) >= _timestamp(run["started_at"]), "invalid run interval")
    duration = run["duration_seconds"]
    _require(type(duration) in (int, float) and math.isfinite(duration) and duration >= 0, "invalid duration")
    path = run["repository_path"]
    _require(type(path) is str and "\x00" not in path
             and (PurePosixPath(path).is_absolute() or PureWindowsPath(path).is_absolute()),
             "invalid recorded repository path")
    _require(type(run["warnings"]) is list and all(type(w) is str for w in run["warnings"]), "invalid warnings")
    primary = _primary(run["primary_result"])
    _require(manifest["primary_result"] == primary.kind.value
             and manifest["entrypoint_started"] == manifest["execution_present"]
             == run["execution_present"] == primary.entrypoint_started
             and ("logs/execution.log" in files) == primary.entrypoint_started,
             "inconsistent execution metadata")
    result = run["result_bundle"]
    _require(type(result) is dict and set(result) == {"attempted", "status", "error"}
             and result["attempted"] is True and result["status"] == "created" and result["error"] is None,
             "incomplete publication")
    _require(type(run["process_exit_code"]) is int and run["process_exit_code"] == primary.process_exit_code,
             "inconsistent process status")
    operation = run["operation"]
    _require(operation in ("bundle", "apply"), "unsupported operation")
    if operation == "bundle":
        _require(not run["dry_run"] and not primary.entrypoint_started
                 and primary.kind is PrimaryResultKind.SUCCESS and not _APPLY_FIELDS.intersection(manifest),
                 "inconsistent manual bundle")
    else:
        _require(not run["dry_run"] or not primary.entrypoint_started, "dry-run executed an entrypoint")
        if primary.success:
            _require((run["dry_run"] and primary.kind is PrimaryResultKind.DRY_RUN_SUCCESS)
                     or (not run["dry_run"] and primary.kind is PrimaryResultKind.SUCCESS and primary.entrypoint_started),
                     "inconsistent apply success")

    expected = None
    if _APPLY_FIELDS <= set(manifest):
        expected = _selection({"repo_id": manifest["repo_id"],
                               **{key: manifest["expected_" + key] for key in _BINDING_FIELDS - {"repo_id"}}})
        _require(not primary.success or expected.base_commit.object_format == binding.base_commit.object_format,
                 "inconsistent expected object format")
        _require(all(manifest["actual_" + key] == manifest[key] for key in _BINDING_FIELDS - {"repo_id"}),
                 "inconsistent actual result context")
    completed = None
    digest = manifest.get("patch_sha256")
    if _RECEIPT_FIELDS <= set(manifest):
        _require(_hex_digest(digest), "invalid patch digest")
        if manifest["completed_commit"] is not None:
            _require(type(manifest["completed_commit"]) is str and primary.success and not run["dry_run"]
                     and primary.entrypoint_started and not context["dirty"]
                     and manifest["completed_commit"] == str(binding.base_commit)
                     and str(expected.base_commit) != manifest["completed_commit"], "inconsistent completion commit")
            completed = binding.base_commit

    expected_files = {"manifest.json", "context.json", "logs/run.json", "changes/staged.patch", "changes/unstaged.patch"}
    if primary.entrypoint_started:
        expected_files.add("logs/execution.log")
    handoff = _handoff(files, context, run)
    _require(version == 1 or handoff == {"environment.json", CHAT_INSTRUCTIONS_NAME},
             "Result 2 requires passive handoff data")
    expected_files.update(handoff)
    runtime = None
    if version == 2 and verify_runtime:
        runtime = read_result_runtime(manifest["runtime"], files, resource_policy=resource_policy)
        _require(runtime.status != "unavailable" or bool(run["warnings"]),
                 "unavailable runtime requires a run warning")
        expected_files.add(runtime.metadata.path)
        if runtime.wheel is not None:
            expected_files.add(runtime.wheel.path)
    elif version == 2:
        # Only this reserved namespace may be excluded from the private
        # repository-only assessment. Unknown root/snapshot members still fail.
        expected_files.update(name for name in files if name.startswith("runtime/"))
    inventory = []
    repository_paths = []
    for kind in ("base", "untracked"):
        entries = manifest[kind + "_entries"]
        _require(type(entries) is list, "invalid result inventory")
        fields = {"path", "size", "git_mode", "object_id"} if kind == "base" else {"path", "size", "mode", "sha256"}
        for entry in entries:
            _require(type(entry) is dict and set(entry) == fields, "invalid result entry schema")
            name = entry["path"]
            _require(type(name) is str and result_member_path(kind + "/" + name) == kind + "/" + name,
                     "invalid result path")
            repository_paths.append(name.encode("utf-8"))
            member = kind + "/" + name
            _require(member not in expected_files, "duplicate result inventory path")
            raw = files[member]
            _require(type(entry["size"]) is int and entry["size"] == len(raw), "result size mismatch")
            mode = entry["git_mode" if kind == "base" else "mode"]
            _require(type(mode) is str and mode in ("100644", "100755"), "invalid result mode")
            zip_mode = modes[member]
            _require(zip_mode is None or bool(zip_mode & 0o111) == (mode == "100755"), "result mode mismatch")
            if kind == "base":
                oid = GitObjectId(entry["object_id"], binding.base_commit.object_format)
                hashed = hashlib.new(oid.object_format.value)
                hashed.update(b"blob " + str(len(raw)).encode("ascii") + b"\0")
                hashed.update(raw)
                _require(hashed.hexdigest() == str(oid), "base blob hash mismatch")
                inventory.append((name, mode, str(oid)))
            else:
                _require(_hex_digest(entry["sha256"]) and hashlib.sha256(raw).hexdigest() == entry["sha256"],
                         "untracked hash mismatch")
            expected_files.add(member)
    validate_repository_paths(repository_paths)
    _require(set(files) == expected_files, "unaccounted result contents")
    has_changes = bool(files["changes/staged.patch"] or files["changes/unstaged.patch"] or manifest["untracked_entries"])
    _require(context["dirty"] == has_changes, "inconsistent dirty state")
    if not context["dirty"]:
        _require(binding.state_fingerprint == CLEAN_FINGERPRINT, "inconsistent clean fingerprint")
    return ResultFacts(ReferenceContext(binding.repo_id, path, binding.base_commit, context["dirty"],
                                        binding.state_fingerprint, binding.fingerprint_algorithm),
                       run["run_id"], operation, run["dry_run"], primary, tuple(run["warnings"]),
                       tuple(sorted(inventory)), expected, digest, completed, version, runtime, bool(handoff))


def capture_result_reference(path: Path, *, resource_policy: ResourcePolicy = DEFAULT_RESOURCE_POLICY,
                             expected_identity: os.stat_result | None = None) -> CapturedResultReference:
    """Own one stable read and complete validation, with no retries or fallback.

    Source errors retain their category. The optional identity is forwarded for
    publication callers; this reader does not change their separate sync/retry
    policy. In particular, it never weakens runtime validation for a pack caller.
    """
    activity("REFERENCE", f"Read and validate explicit Result reference: {path}")
    try:
        try:
            # Publication must never resolve a substituted leaf symlink.
            target = path.resolve(strict=True) if expected_identity is None else path.absolute()
        except RuntimeError as exc:  # pathlib symlink loops on Python 3.12/3.13
            raise ValueError("cannot resolve Result reference path") from exc
        _require(target.lstat().st_size <= resource_policy.max_input_artifact_bytes, "reference exceeds resource limit")
        captured = read_stable_regular_file_with_sha256(
            target, retained_content_limit=resource_policy.max_input_artifact_bytes, allow_path_identity_fallback=True,
            expected_identity=expected_identity, max_bytes=resource_policy.max_input_artifact_bytes)
        _require(captured.content is not None, "reference exceeds resource limit")
        payloads = read_zip_payload_bytes(captured.content, policy=resource_policy, path_normalizer=result_member_path)
        facts = parse_result_payloads(payloads, resource_policy=resource_policy)
        # These are the very bytes just validated, not a second ZIP/path read.
        # Decode only the bounded context again; all semantic checks stay in the
        # existing parser. No mutable parsed object escapes this boundary.
        selected = {entry.relative_path: entry.content for entry in payloads
                    if entry.relative_path in {"context.json", CHAT_INSTRUCTIONS_NAME, ENVIRONMENT_NAME}}
        suffix = _document(selected["context.json"]).get("bundle_suffix", "")
        handoff = (BundleHandoff(selected[CHAT_INSTRUCTIONS_NAME], selected[ENVIRONMENT_NAME])
                   if facts.handoff_present else None)
        return CapturedResultReference(facts, captured.sha256, suffix, handoff)
    except (FileChangedDuringRead, FileSystemOperationError, UnsupportedFileTypeError,
            NotZipArchiveError, ZipPayloadError, OSError, ValueError, TypeError, KeyError,
            UnicodeError, RecursionError, OverflowError, PatchHarborError) as exc:
        raise PatchHarborError(f"invalid Result reference {path}: {exc}", FailureReason.SOURCE_ERROR) from exc


def read_result_reference(path: Path, *, resource_policy: ResourcePolicy = DEFAULT_RESOURCE_POLICY,
                          expected_identity: os.stat_result | None = None) -> tuple[ResultFacts, str]:
    """Compatibility facade: keep the existing facts/hash result and arguments."""
    captured = capture_result_reference(path, resource_policy=resource_policy,
                                        expected_identity=expected_identity)
    return captured.facts, captured.sha256
