"""Prepare one validated patch package outside its target repository."""

from __future__ import annotations

from collections.abc import Iterator
from contextlib import contextmanager
from dataclasses import dataclass
from hashlib import sha256
from pathlib import Path

from patchharbor.progress import activity

from patchharbor.errors import FailureReason, PatchHarborError
from patchharbor.interpreters import (
    ResolvedInterpreter,
    encode_script_file,
    resolve_script_interpreter,
)
from patchharbor.models import BundlePayload
from patchharbor.parser import ParsedScript
from patchharbor.patch_package import ValidatedPatchPackage, parse_package_entrypoint
from patchharbor.platform.paths import is_physically_within
from patchharbor.platform.errors import describe_os_error
from patchharbor.temporary_resources import (
    private_request_directory,
    system_temporary_directory,
    write_private_bytes,
)


@dataclass(frozen=True, slots=True)
class PreparedEntrypoint:
    """One parsed entrypoint with a resolved interpreter and private path."""

    path: Path
    script: ParsedScript
    interpreter: ResolvedInterpreter


@dataclass(frozen=True, slots=True)
class PreparedPatchPackage:
    """Immutable checked inputs ready for a later mutation boundary."""

    entrypoint: PreparedEntrypoint
    payloads: tuple[BundlePayload, ...]
    execution_log_path: Path

    @property
    def warnings(self) -> tuple[str, ...]:
        return self.entrypoint.script.warnings


def _preflight_error(message: str, exit_code: FailureReason) -> PatchHarborError:
    return PatchHarborError(message, exit_code)


def _private_resource_path(root: Path, relative_path: str) -> Path:
    return root.joinpath(*relative_path.split("/"))


def _verified_private_resource(
    root: Path,
    relative_path: str,
    content: bytes,
    *,
    failure_exit: FailureReason,
) -> Path:
    activity("PREPARE", f"Write and hash-verify private entrypoint resource: {relative_path}")
    target = _private_resource_path(root, relative_path)
    expected_hash = sha256(content).digest()
    try:
        write_private_bytes(target, content)
        observed = target.read_bytes()
    except OSError as exc:
        raise _preflight_error(
            f"cannot prepare private package resource: {describe_os_error(exc)}",
            failure_exit,
        ) from exc
    observed_hash = sha256(observed).digest()
    if len(observed) != len(content) or observed_hash != expected_hash:
        raise _preflight_error(
            "private package resource does not match the validated ZIP entry",
            failure_exit,
        )
    activity("PREPARE", f"Private resource verified: {relative_path}", "success")
    return target


def _validated_entrypoint(
    package: ValidatedPatchPackage,
) -> tuple[ParsedScript, ResolvedInterpreter]:
    script = parse_package_entrypoint(package.entrypoint)
    activity("SCRIPT", "Resolve the required Bash/PowerShell interpreter")
    return script, resolve_script_interpreter(script.text)


def _prepare_entrypoint(
    package: ValidatedPatchPackage,
    private_root: Path,
) -> PreparedEntrypoint:
    script, interpreter = _validated_entrypoint(package)
    path = _verified_private_resource(
        private_root / "entrypoint",
        f"script{interpreter.spec.script_suffix}",
        encode_script_file(script.text, interpreter.spec),
        failure_exit=FailureReason.EXECUTION_ERROR,
    )
    return PreparedEntrypoint(
        path=path,
        script=script,
        interpreter=interpreter,
    )


@contextmanager
def prepare_patch_package(
    package: ValidatedPatchPackage,
    *,
    repository: Path,
) -> Iterator[PreparedPatchPackage]:
    """Yield checked private resources and own their complete cleanup."""
    try:
        temporary_root = system_temporary_directory()
    except (OSError, RuntimeError) as exc:
        raise _preflight_error(
            f"cannot resolve the private system temporary directory: {exc}",
            FailureReason.EXECUTION_ERROR,
        ) from exc

    if is_physically_within(
        temporary_root,
        repository,
        candidate_must_exist=True,
        root_must_exist=True,
    ):
        raise _preflight_error(
            "private apply temporary directory is inside the repository",
            FailureReason.EXECUTION_ERROR,
        )

    try:
        with private_request_directory(prefix="patchharbor-apply-") as private_root:
            entrypoint = _prepare_entrypoint(package, private_root)
            yield PreparedPatchPackage(
                entrypoint=entrypoint,
                payloads=package.payloads,
                execution_log_path=private_root / "execution.log",
            )
    except PatchHarborError:
        raise
    except OSError as exc:
        raise _preflight_error(
            f"cannot prepare private patch resources: {describe_os_error(exc)}",
            FailureReason.EXECUTION_ERROR,
        ) from exc
